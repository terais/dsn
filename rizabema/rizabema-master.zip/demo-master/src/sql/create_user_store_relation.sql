--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: user_store_relation; Type: TABLE; Schema: dsn; Owner: postgres
--

CREATE TABLE dsn.user_store_relation (
    user_id character varying(20) NOT NULL,
    store_id character varying(20) NOT NULL
);


ALTER TABLE dsn.user_store_relation OWNER TO postgres;

--
-- Name: user_store_relation user_store_relation_pkey; Type: CONSTRAINT; Schema: dsn; Owner: postgres
--

ALTER TABLE ONLY dsn.user_store_relation
    ADD CONSTRAINT user_store_relation_pkey PRIMARY KEY (user_id, store_id);


--
-- Name: user_store_relation user_store_relation_store_id_fkey; Type: FK CONSTRAINT; Schema: dsn; Owner: postgres
--

ALTER TABLE ONLY dsn.user_store_relation
    ADD CONSTRAINT user_store_relation_store_id_fkey FOREIGN KEY (store_id) REFERENCES dsn.stores(store_id) ON DELETE CASCADE;


--
-- Name: user_store_relation user_store_relation_user_id_fkey; Type: FK CONSTRAINT; Schema: dsn; Owner: postgres
--

ALTER TABLE ONLY dsn.user_store_relation
    ADD CONSTRAINT user_store_relation_user_id_fkey FOREIGN KEY (user_id) REFERENCES dsn.users(user_id) ON DELETE CASCADE;


--
-- Name: TABLE user_store_relation; Type: ACL; Schema: dsn; Owner: postgres
--

GRANT ALL ON TABLE dsn.user_store_relation TO dsn;


--
-- PostgreSQL database dump complete
--

