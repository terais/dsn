--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stores; Type: TABLE; Schema: dsn; Owner: postgres
--

CREATE TABLE dsn.stores (
    store_id character varying(20) NOT NULL,
    store_name character varying(50) NOT NULL,
    address character varying(100) NOT NULL,
    notes character varying(200),
    email character varying(50) NOT NULL,
    phone_number character varying(20)
);


ALTER TABLE dsn.stores OWNER TO postgres;

--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: dsn; Owner: postgres
--

ALTER TABLE ONLY dsn.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (store_id);


--
-- Name: TABLE stores; Type: ACL; Schema: dsn; Owner: postgres
--

GRANT ALL ON TABLE dsn.stores TO dsn;


--
-- PostgreSQL database dump complete
--

