INSERT INTO dsn.users (user_id, username, password, email) VALUES
('3add7ee5bc', '寺居滋', '$2a$10$/By4cojQ/PkL8dE7/we1aelAOh27YUsqX9WenWCp35Pb8Q8kRh026', 'ykhmmsugv@gmail.com'),
('admin', 'admin', '$2a$10$/By4cojQ/PkL8dE7/we1aelAOh27YUsqX9WenWCp35Pb8Q8kRh026', 'ykhmmsugv@gmail.com');

INSERT INTO dsn.stores (store_id, store_name, address, notes, email, phone_number) VALUES
('store003', '銀座 維新號 本店', '東京都中央区銀座８丁目７−２２', NULL, 'ykhmmsugv@gmail.com', '080-5461-6658'),
('store004', '弘善坊', '東京都港区新橋２丁目２０−１５ 新橋駅前ビル1号館 ２Ｆ', NULL, 'ykhmmsugv@gmail.com', '080-5461-6658'),
('store005', '美華園 新橋店', '東京都港区新橋２丁目２０−１５', NULL, 'ykhmmsugv@gmail.com', '080-5461-6658'),
('store006', '九寨溝 銀座店', '東京都中央区銀座７丁目３−１３ ニューギンザビル', NULL, 'ykhmmsugv@gmail.com', '080-5461-6658'),
('store007', '新宿 六', '東京都新宿区新宿６丁目４−２ コスモス新宿18ビル', NULL, 'ykhmmsugv@gmail.com', '080-5461-6658'),
('store001', '中華 銀座亭', '東京都中央区銀座７丁目１１−１０', NULL, 'ykhmmsugv@gmail.com', '080-5461-6658'),
('store002', '麒麟', '東京都中央区銀座６丁目９−１５', '美味しいお店です', 'ykhmmsugv@gmail.com', '080-5461-6658'),
('test', 'test2', 'test', 'test', 'test', 'test');

INSERT INTO dsn.user_store_relation (user_id, store_id) VALUES
('3add7ee5bc', 'store001'),
('3add7ee5bc', 'store002'),
('3add7ee5bc', 'store003'),
('3add7ee5bc', 'store004'),
('3add7ee5bc', 'store005'),
('3add7ee5bc', 'store006'),
('3add7ee5bc', 'store007'),
('3add7ee5bc', 'test');
