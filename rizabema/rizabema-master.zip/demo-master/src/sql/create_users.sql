--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: dsn; Owner: postgres
--

CREATE TABLE dsn.users (
    user_id character varying(32) NOT NULL,
    username character varying(20) NOT NULL,
    password character varying(128) NOT NULL,
    email character varying(50) NOT NULL
);


ALTER TABLE dsn.users OWNER TO postgres;

--
-- Name: users pk_user_id; Type: CONSTRAINT; Schema: dsn; Owner: postgres
--

ALTER TABLE ONLY dsn.users
    ADD CONSTRAINT pk_user_id PRIMARY KEY (user_id);


--
-- Name: TABLE users; Type: ACL; Schema: dsn; Owner: postgres
--

GRANT ALL ON TABLE dsn.users TO dsn;


--
-- PostgreSQL database dump complete
--

