package com.example.demo.dsn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.dsn.model.ConfirmInfo;

@Mapper
public interface ConfirmInfoMapper {

    // レコードを全て取得
    List<ConfirmInfo> getAllConfirmInfo();


    // Insert a new record
    void insertConfirmInfo(ConfirmInfo confirmInfo);
    
    void upsertConfirmInfo(ConfirmInfo confirmInfo);

    // Select a record by user_id and store_id
    ConfirmInfo selectConfirmInfo(Map<String, Object> params);

    // Update a record by user_id and store_id
    void updateConfirmInfo(ConfirmInfo confirmInfo);

    // Delete a record by user_id and store_id
    void deleteConfirmInfo(Map<String, Object> params);

    // Select all records for a specific user_id
    List<ConfirmInfo> selectAllByUserId(String userId);

    // Select all records for a specific store_id
    List<ConfirmInfo> selectAllByStoreId(String storeId);
}
