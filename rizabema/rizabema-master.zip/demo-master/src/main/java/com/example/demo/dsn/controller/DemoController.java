package com.example.demo.dsn.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dsn.mapper.ConfirmInfoMapper;
import com.example.demo.dsn.mapper.StoreMapper;
import com.example.demo.dsn.model.ConfirmInfo;
import com.example.demo.dsn.model.Store;
import com.example.demo.dsn.model.User;
import com.example.demo.dsn.repository.UserRepository;
import com.example.demo.dsn.service.EmailService; 

@Controller
public class DemoController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StoreMapper storeMapper;

    @Autowired
    private ConfirmInfoMapper confirmInfoMapper;

    @Autowired
    private EmailService emailService;

    @Value("${google.maps.api.key}")
    private String googleMapsApiKey;

    @GetMapping("/")
    public String main(Model model) {
        model.addAttribute("googleMapsApiKey", googleMapsApiKey);
        return "main";
    }

    @GetMapping("/accept")
    public String accept(
        @RequestParam String storeId, 
        @RequestParam String userId,
        @RequestParam String message,
        Model model
    ) {
        Store store = storeMapper.selectStoreById(storeId);
        User user = userRepository.findByUserId(userId);

        model.addAttribute("storeName", store.getStoreName());
        model.addAttribute("userName", user.getUsername());

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E) HH時mm分ss秒");
        String formattedDateTime = now.format(formatter);
        model.addAttribute("formattedDateTime", formattedDateTime); 

        emailService.sendNoticeToUser(store, user, message);

        return "accept";
    }

    @GetMapping("/confirm")
    public String confirm( 
        @RequestParam String userId,
        @RequestParam String storeId,
        Model model
    ) {
        Store store = storeMapper.selectStoreById(storeId);
        User user = userRepository.findByUserId(userId);

        ConfirmInfo confirmInfo = confirmInfoMapper.selectConfirmInfo(Map.of("userId", user.getUserId(), "storeId", store.getStoreId()));

        model.addAttribute("storeName", store.getStoreName());
        model.addAttribute("storePhoneNumber", store.getPhoneNumber());
        model.addAttribute("storeEmail", store.getEmail());
        model.addAttribute("storeAddress", store.getAddress());
        model.addAttribute("userName", user.getUsername());
        model.addAttribute("userEmail", user.getEmail());
        model.addAttribute("guestNumber", confirmInfo.getGuestNumber());
        model.addAttribute("time", confirmInfo.getTime());
        model.addAttribute("budget", confirmInfo.getBudget());
        model.addAttribute("isSmoke", confirmInfo.getIsSmoke());
        model.addAttribute("alcohol", confirmInfo.getAlcohol());

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E) HH時mm分ss秒");
        String formattedDateTime = now.format(formatter);
        model.addAttribute("formattedDateTime", formattedDateTime); 

        emailService.sendFinalConfirmToStore(store, user, confirmInfo);

        return "confirm";
    }
}