
package com.example.demo.dsn.controller;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dsn.model.User;
import com.example.demo.dsn.service.EmailService;
import com.example.demo.dsn.service.UserService;

import jakarta.servlet.http.HttpSession;

@RestController
public class AuthController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserService userService;

    @PostMapping("/user/login")
    public @ResponseBody Map<String, String> login(@RequestBody Map<String, String> credentials, HttpSession session) {
        String identifier = credentials.get("identifier"); // userIdまたはemail
        String password = credentials.get("password");

        User user = userService.authenticate(identifier, password);

        if (user != null) {
            session.setAttribute("username", user.getUsername());
            session.setMaxInactiveInterval(30 * 60);
            return Map.of("userId", user.getUserId(), "username", user.getUsername());
        } else {
            throw new RuntimeException("Invalid credentials");
        }
    }

    @PostMapping("/register")
    public @ResponseBody ResponseEntity<Map<String, String>> register(@RequestBody Map<String, String> registrationData) {
        String account = registrationData.get("account");
        String email = registrationData.get("email");
        String userId = generateShortUUID(); // 自動生成されたuser_id
        String password = generateShortUUID(); // 自動生成されたパスワード

        if (userService.checkEmailUser(email)) {
            return ResponseEntity.internalServerError().build();
        }
        userService.registerUser(userId, account, password, email);
        
        // メール送信（メール送信サービスを使用）
        emailService.sendCredentials(email, userId, password);

        return new ResponseEntity<Map<String,String>>(Map.of("message", "Registration successful, please check your email."), HttpStatus.OK);
    }

    @PostMapping("/logout")
    public @ResponseBody Map<String, String> logout(HttpSession session) {
        session.invalidate(); // セッションを無効化
        return Map.of("message", "ログアウト成功");
    }

    @GetMapping("/check-login")
    public @ResponseBody Map<String, Object> checkLogin(HttpSession session) {
        String username = (String) session.getAttribute("username");
        boolean loggedIn = username != null;
        username = (username == null) ? "" : username;
        if (loggedIn) {
            User user = userService.findByUsername(username);
            
            // user = userService.authenticate(username, user.getPassword());

            if (user != null) {
                session.setAttribute("username", user.getUsername());
                session.setMaxInactiveInterval(30 * 60);
                return Map.of("loggedIn", true, "username", username, "email", user.getEmail());
            }
        }
        return Map.of("loggedIn", false, "username", "", "email", ""); 
    }

    @PostMapping("/update-password")
    public @ResponseBody ResponseEntity<Map<String, String>> updatePassword(@RequestBody Map<String, String> requestData, HttpSession session) {
        String currentPassword = requestData.get("currentPassword");
        String newPassword = requestData.get("newPassword");
        String username = (String) session.getAttribute("username");

        if (username == null) {
            return ResponseEntity.internalServerError().build();
            //Map.of("message", "ログインしていません");
        }

        User user = userService.authenticate(username, currentPassword);

        if (user == null) {
            return ResponseEntity.status(401).build();
            //Map.of("message", "現在のパスワードが正しくありません");
        }

        userService.updatePassword(username, newPassword);
        emailService.sendPasswordChangeNotification(user.getEmail(), user); // パスワード変更通知メールを送信
        return ResponseEntity.ok().build();// Map.of("message", "パスワード変更成功");
    }

    @PostMapping("/update-user-info")
    public @ResponseBody ResponseEntity<Map<String, String>> updateUserInfo(@RequestBody Map<String, String> requestData, HttpSession session) {
        String username = (String) session.getAttribute("username");

        if (username == null) {
            return ResponseEntity.internalServerError().build();
            // return Map.of("message", "ログインしていません");
        }

        String newUsername = requestData.get("newUsername");
        String email = requestData.get("newEmail");

        if (userService.checkEmailUser(email)) {
            String dbUsername = userService.findByEmailUser(email).getUsername(); 
            if(!dbUsername.equals(username)) {
                return ResponseEntity.internalServerError().build();
            }
        }

        userService.updateUserInfo(username, newUsername, email);
        session.setAttribute("username", newUsername);
        
        emailService.sendUserInfoChangeNotification(email, newUsername);

        return ResponseEntity.ok().build();
    }

    private String generateShortUUID() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 10);
    }
}
