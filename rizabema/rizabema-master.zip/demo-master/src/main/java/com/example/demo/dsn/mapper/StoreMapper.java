package com.example.demo.dsn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.dsn.model.Store;

@Mapper
public interface StoreMapper {

    void insertStore(Store store);

    Store selectStoreById(String storeId);

    List<Store> selectAllStores();

    void updateStore(Store store);

    void deleteStore(String storeId);

    boolean existsByStoreId(String storeId);
}

