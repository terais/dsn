package com.example.demo.dsn.model;

import lombok.Data;

@Data
public class LoginRequest {
    private String usernameOrEmail;
    // private String userIdOrEmail;
    private String password;

    // デフォルトコンストラクタ
    public LoginRequest() {
    }

    // 全フィールドを設定するコンストラクタ
    public LoginRequest(String usernameOrEmail, String password) {
        this.usernameOrEmail = usernameOrEmail;
        this.password = password;
    }
}

