package com.example.demo.dsn.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.dsn.model.User;
import com.example.demo.dsn.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String usernameOrEmail) throws UsernameNotFoundException {
        User user = userRepository.findByUserId(usernameOrEmail);
        if (user == null) {
            user = userRepository.findByEmail(usernameOrEmail).get(0);
        }
        if (user == null) {
            throw new UsernameNotFoundException("ユーザーが見つかりません");
        }
        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUserId())
                .password(user.getPassword())
                .authorities("USER") // 必要に応じて権限を設定
                .build();
    }
}