package com.example.demo.dsn.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.example.demo.dsn.controller.ApiController.SubmissionData;
import com.example.demo.dsn.mapper.StoreMapper;
import com.example.demo.dsn.model.ConfirmInfo;
import com.example.demo.dsn.model.Store;
import com.example.demo.dsn.model.User;
import com.example.demo.dsn.repository.UserRepository;
import com.example.demo.dsn.service.EmailService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender javaMailSender;

    public EmailServiceImpl(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StoreMapper storeMapper;
    
    @Value("${google.maps.api.key}")
    private String googleMapsApiKey;

    @Value("${project.url}")
    private String projectUrl;

    @Override
    public void sendCredentials(String email, String userId, String password) {

        User user = userRepository.findByUserId(userId);

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject(user.getUsername() + "様 ログイン情報");
        message.setText("ユーザーID: " + userId + "\nパスワード: " + password);
        javaMailSender.send(message);
    }

    @Override
    public void sendPasswordChangeNotification(String to, User user) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("【"+ user.getUsername() +" 様】パスワードが変更されました");
        message.setText("新パスワード：" + user.getPassword() + "\nご確認ください");
        javaMailSender.send(message);
    }

    
    @Override
    public void sendUserInfoChangeNotification(String to, String username) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("【"+ username +" 様】ユーザー情報が変更されました");
        message.setText("ご確認ください");
        javaMailSender.send(message);
    }

    @Override
    public void sendConfirmToStore(String toId, String fromId, SubmissionData data) {
        Store store = storeMapper.selectStoreById(toId);
        User user = userRepository.findByUserId(fromId);
        String time = data.getTime();
        if (!time.equals("24later")) {
            time += "時以降";
        } else {
            time = "24時以降";
        }

        String guestNumber = data.getGuestNumber().replaceAll("[^0-9]", "");
        
        String budget = data.getBudget();
        switch (data.getBudget()) {
            case "unspecified":
                budget = "の 指定は無し";
                break;
            case "under1000":
                budget = "は 1,000円未満";
                break;
            case "over10000":
                budget = "は 10,000円以上";
                break;
            default:        
                budget = data.getBudget().replaceAll("to", "～");
                String[] parts = budget.split("～");
                budget = "は" + String.format("%,d", Integer.parseInt(parts[0])) + "～" + String.format("%,d", Integer.parseInt(parts[1])) + "円";
                break;
        }
        String isSmoke = data.isSmokingAllowed() ? "<p>喫煙を希望します</p>" : ""; 
        String alcohol = data.isAlcohol() ? "<p>お酒の提供を希望します</p>" : ""; 

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E) ");
        String formattedDateTime = now.format(formatter);

        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setTo(store.getEmail());
            helper.setSubject(user.getUsername() + "様から予約の確認です");
            
            String htmlContent = "<!DOCTYPE html>" +
                "<html lang=\"ja\">" +
                "<head>" +
                "    <meta charset=\"UTF-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "    <title>Confirmation Email</title>" +
                "    <style>" +
                "        body {" +
                "            font-family: Arial, sans-serif;" +
                "            background-color: #f0f0f0;" +
                "            margin: 0;" +
                "            padding: 0;" +
                "        }" +
                "" +
                "        .email-wrapper {" +
                "            width: 100%;" +
                "            height: 100%;" +
                "            display: table;" +
                "            text-align: center;" +
                "        }" +
                "" +
                "        .email-content {" +
                "            display: table-cell;" +
                "            vertical-align: middle;" +
                "        }" +
                "" +
                "        .circle-button {" +
                "            background-color: #00bfff;" +
                "            border: none;" +
                "            color: white;" +
                "            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);" +
                "            box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);" +
                "            border-radius: 50%;" +
                "            width: 300px;" +
                "            height: 300px;" +
                "            font-size: 24px;" +
                "            cursor: pointer;" +
                "            text-decoration: none; /* ボタンのリンクスタイル */" +
                "            display: inline-block;" +
                "            line-height: 250px; /* ボタンの高さと同じ */" +
                "            transition: box-shadow 0.1s, transform 0.1s;" +
                "        }" +
                "" +
                "        .circle-button:hover {" +
                "            background-color: #0099cc;" +
                "        }" +
                "" +
                "        .circle-button:active {" +
                "            box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.2);" +
                "            transform: translateY(2px);" +
                "        }" +
                "        .input-text {" +
                "            width: 80%;" +
                "            margin: 10px auto;" +
                "            padding: 10px;" +
                "            font-size: 16px;" +
                "            border: 1px solid #ccc;" +
                "            border-radius: 5px;" +
                "            resize: vertical; /* 垂直方向にリサイズ可能 */" +
                "        }" +
                "    </style>" +
                "</head>" +
                "<body>" +
                "    <div class=\"email-wrapper\">" +
                "        <div class=\"email-content\">" +
                "            <h2>" + store.getStoreName() + "様</h2>" +
                "            <p>本日 " + formattedDateTime + time + " より</p>" + 
                "            <p>" + guestNumber + "名様ご予約可能でしょうか？</p>" +
                "            <p>予算" + budget + " です</p>" +
                "            " + alcohol +
                "            " + isSmoke +     
                "            <p>" + user.getUsername() + "様に御質問＆御要望はありますか？</p>" + 
                "            <form action=\"" + projectUrl + "/accept\" method=\"GET\">" +
                "                <input type=\"hidden\" name=\"storeId\" value=\"" + store.getStoreId() + "\">" +
                "                <input type=\"hidden\" name=\"userId\" value=\"" + user.getUserId() + "\">" +
                "                <textarea  type=\"text\" class=\"input-text\" id=\"message\" name=\"message\"></textarea>" +
                "                <button type=\"submit\" class=\"circle-button\">OK</button>" +
                "            </form>" +
                "        </div>" +
                "    </div>" +
                "</body>" +
                "</html>";
            helper.setText(htmlContent, true);
        } catch (MessagingException e) {
            e.printStackTrace();
        }

        javaMailSender.send(mimeMessage);
    }
    
    @Override
    public void sendNoticeToUser(Store store, User user, String message) {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setTo(user.getEmail());
            helper.setSubject("【" + store.getStoreName() + "】" + "受け入れ可能です");

            String remarks = store.getNotes() == null ? "" : "備考:" + store.getNotes();
            String phoneNumber = "<a href=\"tel:+81" + store.getPhoneNumber().substring(1).replaceAll("-","") + "\">";
            phoneNumber += "Tel:" + store.getPhoneNumber() + "</a>";
            message = message == "" || message == null ? "" : "<div style=\"text-align: center;\">" +  
                                                            "御質問＆ご要望は以下となります</div>" +
                                                            "<div style=\"text-align: center;\">[" +  
                                                                message + "]</div>";

            String address = store.getAddress();
            String encodedAddress = URLEncoder.encode(address, "UTF-8");

            String htmlContent = "<!DOCTYPE html>" + 
                "<html lang=\"ja\">" + 
                "<head>" + 
                "    <meta charset=\"UTF-8\">" + 
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" + 
                "    <style>" + 
                "        #map-image-container {" + 
                "            position: relative;" + 
                "            width: 480px;" + 
                "            height: 320px;" + 
                "            margin: auto;" + 
                "        }" + 
                "        #map-image {" + 
                "            width: 100%;" + 
                "            height: auto;" + 
                "        }" + 
                "        #google-maps-button {" + 
                "            display: block;" + 
                "            margin: 10px auto;" + 
                "            background-color: #4285F4;" + 
                "            color: white;" + 
                "            padding: 10px 20px;" + 
                "            border: none;" + 
                "            cursor: pointer;" + 
                "            font-size: 16px;" + 
                "            text-align: center;" + 
                "            text-decoration: none;" + 
                "            border-radius: 5px;" + 
                "            width: 250px;" + 
                "        }" + 
                "    </style>" + 
                "</head>" + 
                "<body>" +
                "<h1 style=\"text-align: center;\">" + user.getUsername() + " 様</h1>" +  
                "<div style=\"text-align: center;\">" +  
                    store.getStoreName() + "です</div>" +
                    message + 
                "<br>" +
                "<div style=\"text-align: center;\">" +
                    "予約はまだ確定していません</div>" +
                "<div style=\"text-align: center;\">" +
                    "問題なければ確定ボタンを押下してください</div>" +
                
                    "<div style=\"text-align: center;\">" +
                    "<a href=" + projectUrl + "/confirm?userId=" + user.getUserId() + "&storeId=" + store.getStoreId() + ">" +
                    "<button style=\"background-color: #4CAF50; color: white; padding: 14px 20px; border: none; cursor: pointer;\">" +
                    "確定する" +
                    "</button>" +
                    "</a>" +
                    "</div>" +

                "<div style=\"text-align: center;\">" +
                    "お問い合わせの際はお手数ですが電話にて確認してください</div>" +
                "<div style=\"text-align: center;\">" +
                    phoneNumber +"</div>" + 
                "<div style=\"text-align: center;\">" +
                    "Mail:"+ store.getEmail() +"</div>" + 
                "<div style=\"text-align: center;\">" +
                    "住所:" + store.getAddress() + "</div>" +
                "<div style=\"text-align: center;\">" +
                    remarks + "</div>" +
                "    <div id=\"map-image-container\">" + 
                "        <a href=\"https://www.google.com/maps/search/?api=1&query=" + encodedAddress + "\" id=\"google-maps-link\" target=\"_blank\">" + 
                "            <img id=\"map-image\" src=\"https://maps.googleapis.com/maps/api/staticmap?center=" + encodeURIComponent(address) + "&zoom=17&size=480x320&markers=color:red%7C" + encodeURIComponent(address) + "&key=" + googleMapsApiKey + "\" alt=\"Map Image\">" + 
                "        </a>" + 
                "        <a href=\"https://www.google.com/maps/search/?api=1&query=" + encodedAddress + "\" target=\"_blank\">" + 
                "            <button id=\"google-maps-button\">Google Mapで開く</button>" + 
                "        </a>" + 
                "    </div>" + 
                "</body>" + 
                "</html>";

            helper.setText(htmlContent, true);
        } catch (MessagingException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        javaMailSender.send(mimeMessage);
    }
    
    @Override
    public void sendFinalConfirmToStore(Store store, User user, ConfirmInfo confirmInfo) {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setTo(user.getEmail());
            helper.setSubject("【" + store.getStoreName() + " 様】予約確定");

            // 現在の日時をフォーマットする
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E) HH時mm分ss秒");
            String formattedDateTime = now.format(formatter);

            // HTMLコンテンツの生成
            String htmlContent = "<!DOCTYPE html>" + 
                "<html lang=\"ja\">" + 
                "<head>" + 
                "    <meta charset=\"UTF-8\">" + 
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" + 
                "    <style>" + 
                "        body { font-family: Arial, sans-serif; line-height: 1.6; }" + 
                "        .container { width: 80%; margin: auto; padding: 20px; }" + 
                "        h1 { color: #333; }" + 
                "        p { margin: 0 0 10px; }" + 
                "        .highlight { font-weight: bold; }" + 
                "    </style>" + 
                "</head>" + 
                "<body>" +
                "    <div class=\"container\">" +
                "        <h1>" + store.getStoreName() + " 様</h1>" +
                "        <p>" + user.getUsername() + " 様より以下内容で予約を確定しました</p>" +
                "        <ul>" +
                "            <li><span class=\"highlight\">" + confirmInfo.getGuestNumber() + "</span></li>" +
                "            <li><span class=\"highlight\">" + confirmInfo.getTime() + "</span> 来店予定</li>" +
                "            <li>予算は <span class=\"highlight\">" + confirmInfo.getBudget() + "</span></li>" +
                (confirmInfo.getIsSmoke() != null && confirmInfo.getIsSmoke() ? 
                    "<li>喫煙希望します</li>" : 
                    "<li>喫煙希望はありません</li>") +
                (confirmInfo.getAlcohol() != null && confirmInfo.getAlcohol() ? 
                    "<li>お酒の提供希望します</li>" : 
                    "<li>お酒の提供希望はありません</li>") +
                "        </ul>" +
                "        <p>何かあれば <span class=\"highlight\">" + user.getUsername() + " 様</span> とやりとりください</p>" +
                "        <p>Mail: <span class=\"highlight\">" + user.getEmail() + "</span> 様</p>" +
                "        <p>" + formattedDateTime + "</p>" +
                "    </div>" +
                "</body>" + 
                "</html>";

            // メール本文にHTMLコンテンツを設定
            helper.setText(htmlContent, true);
        } catch (MessagingException e) {
            e.printStackTrace();
        }

        javaMailSender.send(mimeMessage);
    }

    private String encodeURIComponent(String component) throws UnsupportedEncodingException {
        return URLEncoder.encode(component, "UTF-8")
                .replaceAll("\\+", "%20")  // スペースの置換
                .replaceAll("%21", "!")
                .replaceAll("%27", "'")
                .replaceAll("%28", "(")
                .replaceAll("%29", ")")
                .replaceAll("%7E", "~");
    }
}
