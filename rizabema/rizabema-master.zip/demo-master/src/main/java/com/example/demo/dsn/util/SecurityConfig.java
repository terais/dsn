package com.example.demo.dsn.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.example.demo.dsn.service.CustomUserDetailsService;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class).build();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        CustomAuthenticationFilter customAuthenticationFilter = new CustomAuthenticationFilter(userDetailsService);
        customAuthenticationFilter.setFilterProcessesUrl("/store/login");

        http
            .csrf().disable()
            .authorizeRequests()
                .requestMatchers("/static/**", "/css/**", "/js/**", "/img/**").permitAll()
                .requestMatchers("/", "/store/login", "/register", "/check-login", "/logout", "/update-password", "/update-user-info", "/api/submit", "/api/markers", "/user/login", "/accept", "/confirm").permitAll()
                .requestMatchers("/store/master").authenticated()
                .anyRequest().authenticated()
                .and()
            .formLogin()
                .loginPage("/store/login")
                .successForwardUrl("/store/master")
                .permitAll()
                .and()
            .logout()
                .permitAll();

        return http.build();
    }
    
    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
}