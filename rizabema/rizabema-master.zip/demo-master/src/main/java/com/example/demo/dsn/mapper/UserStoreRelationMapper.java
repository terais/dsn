package com.example.demo.dsn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.dsn.model.Store;

@Mapper
public interface UserStoreRelationMapper {
    
    void insertUserStoreRelation(@Param("userId") String userId, @Param("storeId") String storeId);

    List<Store> selectStoresByUserId(@Param("userId") String userId);
    
    List<Store> selectStoresByAdmin();

    Store selectStoreById(@Param("storeId") String storeId,@Param("userId") String  userId);
    
    Store selectStoreByIdAdmin(@Param("storeId") String  storeId);

    void deleteUserStoreRelation(@Param("userId") String userId, @Param("storeId") String storeId);

}
