package com.example.demo.dsn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dsn.mapper.StoreMapper;
import com.example.demo.dsn.mapper.UserStoreRelationMapper;
import com.example.demo.dsn.model.Store;

@Service
public class StoreService {

    @Autowired
    private StoreMapper storeMapper;

    @Autowired
    private UserStoreRelationMapper userStoreRelationMapper;

    public List<Store> getStoresByUserId(String userId) {
        return userStoreRelationMapper.selectStoresByUserId(userId);
    }

    public Store getStoreById(String storeId, String userId) {
        return userStoreRelationMapper.selectStoreById(storeId, userId);
    }

    public Store getStoreByIdAdmin(String storeId) {
        return userStoreRelationMapper.selectStoreByIdAdmin(storeId);
    }

    public void createStore(Store store, String userId) {
        storeMapper.insertStore(store);
        userStoreRelationMapper.insertUserStoreRelation(userId, store.getStoreId());
    }

    public void updateStore(Store store) {
        storeMapper.updateStore(store);
    }

    public void deleteStore(String storeId, String userId) {
        userStoreRelationMapper.deleteUserStoreRelation(userId, storeId);
    }
}
