package com.example.demo.dsn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dsn.mapper.ConfirmInfoMapper;
import com.example.demo.dsn.mapper.StoreMapper;
import com.example.demo.dsn.model.ConfirmInfo;
import com.example.demo.dsn.model.Store;
import com.example.demo.dsn.service.EmailService;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@RestController
public class ApiController {
    
    @Autowired
    private StoreMapper storeMapper;

    @Autowired
    private ConfirmInfoMapper confirmInfoMapper;
    
    @Autowired
    private EmailService emailService;
    
    @GetMapping("/api/markers")
    public ResponseEntity<List<Store>> getAllStores() {
        try {
            List<Store> markers = storeMapper.selectAllStores();
            return ResponseEntity.ok(markers);
        } catch (Exception e) {
            e.printStackTrace(); // エラーログを表示
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/api/submit")
    public String submitData(@RequestBody SubmissionData data) {
        String userId = data.getUserId();
        List<String> selectedStoreIds = data.getSelectedStoreIds();

        for (String id : selectedStoreIds) {
            emailService.sendConfirmToStore(id, userId, data);

            String budget = data.getBudget();
            switch (data.getBudget()) {
                case "unspecified":
                    budget = "指定は無し";
                    break;
                case "under1000":
                    budget = "1,000円未満";
                    break;
                case "over10000":
                    budget = "10,000円以上";
                    break;
                default:        
                    budget = data.getBudget().replaceAll("to", "～");
                    String[] parts = budget.split("～");
                    budget = String.format("%,d", Integer.parseInt(parts[0])) + "～" + String.format("%,d", Integer.parseInt(parts[1])) + "円";
                    break;
            }
            String time = data.getTime();
            if (!time.equals("24later")) {
                time += "時以降";
            } else {
                time = "24時以降";
            }
            String guestNumber = data.getGuestNumber().replaceAll("[^0-9]", "");
            guestNumber = guestNumber.equals("10") ? guestNumber + " 名様以上" : guestNumber + " 名様";
            ConfirmInfo confirmInfo = new ConfirmInfo(
                data.getUserId(), 
                id, 
                guestNumber,
                time,
                budget,
                data.isSmokingAllowed(), 
                data.isAlcohol()
            );
            confirmInfoMapper.upsertConfirmInfo(confirmInfo);
        }

        return "Data received successfully";
    }

    // データの受け取り用クラス
    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SubmissionData {
        private String userId;
        private List<String> selectedStoreIds;
        private String time;
        private String guestNumber;
        private String budget;
        private boolean smokingAllowed;
        private boolean alcohol;
    }
}
