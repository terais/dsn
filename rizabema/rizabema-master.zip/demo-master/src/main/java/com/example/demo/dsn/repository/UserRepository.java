package com.example.demo.dsn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.dsn.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

    User findByUserIdAndPassword(String userId, String password);
    User findByEmailAndPassword(String email, String password);
    User findByUserIdOrEmail(String userId, String email);

    User findByUserId(String userId);
    List<User> findByEmail(String email);
    User findByUsername(String username);
}