package com.example.demo.dsn.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dsn.mapper.StoreMapper;
import com.example.demo.dsn.mapper.UserStoreRelationMapper;
import com.example.demo.dsn.model.Store;
import com.example.demo.dsn.service.StoreService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/store")
public class StoreController {

    @Autowired
    private UserStoreRelationMapper userStoreRelationMapper;

    @Autowired
    private StoreMapper storeMapper;

    @Autowired
    private StoreService storeService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @GetMapping("/login")
    public String login() {
        return "storeLogin";
    }

    @PostMapping("/login")
    public String login(@RequestParam String usernameOrEmail, @RequestParam String password, HttpServletRequest request) {
        try {
            // ユーザー認証処理
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(usernameOrEmail, password)
            );
            SecurityContextHolder.getContext().setAuthentication(authentication);
            return "redirect:/store/master";
        } catch (BadCredentialsException e) {
            // 認証失敗時の処理
            return "redirect:/store/login?error=true";
        }
    }

    @PostMapping("/master")
    public String storeMaster(Authentication authentication, Model model) {
        String userId = authentication.getName();
        List<Store> stores = new ArrayList<>();
        if (userId.equals("admin")) {
            stores = userStoreRelationMapper.selectStoresByAdmin();
        } else {
            stores = userStoreRelationMapper.selectStoresByUserId(userId);
        }
        model.addAttribute("stores", stores);
        model.addAttribute("userId", userId);
        return "storeMaster";
    }

    // 新規ストアの作成
    @PostMapping("/create")
    public ResponseEntity<String> createNewStore(@RequestParam("storeId") String storeId,
                                                 @RequestParam("storeName") String storeName,
                                                 @RequestParam("address") String address,
                                                 @RequestParam("notes") String notes,
                                                 @RequestParam("email") String email,
                                                 @RequestParam("phoneNumber") String phoneNumber,
                                                 @RequestParam("userId") String userId) {
        // Storeの新規作成処理
        storeMapper.insertStore(new Store(storeId, storeName, address, notes, email, phoneNumber));
        userStoreRelationMapper.insertUserStoreRelation(userId, storeId);

        return ResponseEntity.ok("Store created successfully");
    }

    @PostMapping("/store/update")
    public String updateStore(@RequestParam String storeId, @RequestParam String storeName, @RequestParam String address,
                              @RequestParam String notes, @RequestParam String email, @RequestParam String phoneNumber) {
        return "redirect:/store/master";
    }

    @GetMapping("/exists")
    public ResponseEntity<Boolean> checkStoreExists(@RequestParam("storeId") String storeId) {
        boolean exists = storeMapper.existsByStoreId(storeId);
        return ResponseEntity.ok(exists);
    }

    @DeleteMapping("/delete")
    public String delete(@RequestParam("storeId") String storeId, @RequestParam("userId") String userId) {
        storeMapper.deleteStore(storeId);
        userStoreRelationMapper.deleteUserStoreRelation(userId, storeId);
        return "redirect:/store/master";
    }

    @GetMapping("/update")
    public ResponseEntity<Store>  updateStoreForm(@RequestParam("storeId") String storeId, @RequestParam("userId") String userId) {
        Store store = new Store();//storeService.getStoreById(storeId, userId);
        if (userId.equals("admin")) {
            store = storeService.getStoreByIdAdmin(storeId);
        } else {
            store = storeService.getStoreById(storeId, userId);
        }
        if (store == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(store, HttpStatus.OK);
    }

    @PostMapping("/update")
    public ResponseEntity<String> updateStore(@RequestParam Map<String, String> params) {
        try {
            Store store = new Store();
            store.setStoreId(params.get("storeId"));
            store.setStoreName(params.get("storeName"));
            store.setAddress(params.get("address"));
            store.setNotes(params.get("notes"));
            store.setEmail(params.get("email"));
            store.setPhoneNumber(params.get("phoneNumber"));

            storeService.updateStore(store);
            return ResponseEntity.ok("Store updated successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating store: " + e.getMessage());
        }
    }
}
