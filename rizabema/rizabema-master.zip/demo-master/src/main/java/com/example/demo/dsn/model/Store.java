package com.example.demo.dsn.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Store {
        private String storeId;
        private String storeName;
        private String address;
        private String notes;
        private String email;
        private String phoneNumber;
}
