package com.example.demo.dsn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dsn.model.User;
import com.example.demo.dsn.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User authenticate(String identifier, String password) {
        User user = userRepository.findByUserIdOrEmail(identifier, identifier);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        } else {
            return null; // 認証失敗
        }
    }

    public void registerUser(String userId, String username, String password, String email) {
        User user = new User();
        user.setUserId(userId);
        user.setUsername(username);
        String encodedPassword = passwordEncoder.encode(password); 
        user.setPassword(encodedPassword);
        user.setEmail(email);
        userRepository.save(user);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public void updatePassword(String username, String newPassword) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            String encodedPassword = passwordEncoder.encode(newPassword); // パスワードの暗号化
            user.setPassword(encodedPassword);
            userRepository.save(user);
        }
    }

    public void updateUserInfo(String userId, String newUsername, String email) {
        User user = userRepository.findByUsername(userId);
        if (user != null) {
            user.setUsername(newUsername);
            user.setEmail(email);
            userRepository.save(user);
        }
    }

    public boolean checkEmailUser(String email) {
        List<User> users = userRepository.findByEmail(email);
        if (users != null && users.size() != 0) {
            return true;
        }
        return false;
    }

    public User findByEmailUser(String email) {
        List<User> users = userRepository.findByEmail(email);
        return users.get(0);
    }
}
