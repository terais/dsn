package com.example.demo.dsn.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfirmInfo {

    private String userId;
    private String storeId;
    private String guestNumber;
    private String time;
    private String budget;
    private Boolean isSmoke;
    private Boolean alcohol;
}

