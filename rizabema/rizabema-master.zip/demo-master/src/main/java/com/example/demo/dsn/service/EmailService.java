package com.example.demo.dsn.service;

import com.example.demo.dsn.controller.ApiController.SubmissionData;
import com.example.demo.dsn.model.ConfirmInfo;
import com.example.demo.dsn.model.Store;
import com.example.demo.dsn.model.User;

public interface EmailService {
    void sendCredentials(String email, String userId, String password);
    
    void sendPasswordChangeNotification(String to, User user);

    void sendUserInfoChangeNotification(String to, String username);

    void sendConfirmToStore(String toId, String fromId, SubmissionData data);

    void sendNoticeToUser(Store store, User user, String message);

    void sendFinalConfirmToStore(Store store, User user, ConfirmInfo confirmInfo);
}
