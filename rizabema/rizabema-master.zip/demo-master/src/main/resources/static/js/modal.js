document.addEventListener('DOMContentLoaded', function() {
    const loginLink = document.getElementById('login-link');
    const registerLink = document.getElementById('register-link');
    const logoutLink = document.getElementById('logout-link');
    const usernameSpan = document.getElementById('username');
    const userIdSpan = document.getElementById('userId');
    const menu = document.getElementById('menu');
    const toggleMarkerDataButton = document.getElementById('toggleMarkerDataButton');
    const hamburgerMenu = document.getElementById('hamburger-menu');
    let isMenuOpen = false; // メニューの開閉状態を追跡するフラグ

    function updateMenu(loggedIn) {
        if (loggedIn) {
            loginLink.classList.add('hidden');
            registerLink.classList.add('hidden');
            logoutLink.classList.remove('hidden');
            document.getElementById('user-password').classList.remove('hidden');
            document.getElementById('user-info-link').classList.remove('hidden');
            document.getElementById('login-info').style.display = 'block';
            document.getElementById('markerDataDisplay').style.display = 'block';
            document.getElementById('submitButton').style.display = 'block';

            document.getElementById('login-link').style.display = 'none';
            document.getElementById('register-link').style.display = 'none';
            document.getElementById('logout-link').style.display = 'block';
            document.getElementById('user-password').style.display = 'block';
            document.getElementById('user-info-link').style.display = 'block';
            document.getElementById('toggleMarkerDataButton').style.display = 'block';
        } else {
            loginLink.classList.remove('hidden');
            registerLink.classList.remove('hidden');
            logoutLink.classList.add('hidden');
            document.getElementById('user-password').classList.add('hidden');
            document.getElementById('user-info-link').classList.add('hidden');
            document.getElementById('login-info').style.display = 'none';
            document.getElementById('markerDataDisplay').style.display = 'none';
            document.getElementById('submitButton').style.display = 'none';

            document.getElementById('login-link').style.display = 'block';
            document.getElementById('register-link').style.display = 'block';
            document.getElementById('logout-link').style.display = 'none';
            document.getElementById('user-password').style.display = 'none';
            document.getElementById('user-info-link').style.display = 'none';
            document.getElementById('toggleMarkerDataButton').style.display = 'none';
        }
    }

    // ログイン成功時にusernameとuserIdを設定する関数
    function setUserData(username, userId) {
        usernameSpan.innerText = username;
        userIdSpan.innerText = userId;
    }

    fetch('/check-login')
        .then(response => response.json())
        .then(data => {
            console.log(data.loggedIn)
            if (data.loggedIn) {
                setUserData(data.username, data.userId);
                updateMenu(true);
            } else {
                updateMenu(false);
            }
        });

        loginLink.addEventListener('click', function(event) {
            event.preventDefault();
            Swal.fire({
                title: 'ログイン',
                html: `
                    <input type="text" id="swal-identifier" class="swal2-input" placeholder="ユーザーIDまたはメールアドレス">
                    <input type="password" id="swal-password" class="swal2-input" placeholder="パスワード">
                `,
                showCancelButton: true,
                confirmButtonText: 'ログイン',
                cancelButtonText: 'キャンセル',
                didOpen: () => {
                    const identifierInput = Swal.getPopup().querySelector('#swal-identifier');
                    const passwordInput = Swal.getPopup().querySelector('#swal-password');
        
                    // 半角英数字のみを許可するためのリアルタイムバリデーション
                    identifierInput.addEventListener('input', function() {
                        this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
                    });
        
                    passwordInput.addEventListener('input', function() {
                        this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
                    });
                },
                preConfirm: () => {
                    const identifier = Swal.getPopup().querySelector('#swal-identifier').value;
                    const password = Swal.getPopup().querySelector('#swal-password').value;
        
                    if (!identifier || !password) {
                        Swal.showValidationMessage('ユーザーIDまたはメールアドレスとパスワードを入力してください');
                        return false;
                    }
        
                    return { identifier, password };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const { identifier, password } = result.value;
                    fetch('/user/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ identifier, password })
                    }).then(response => {
                        if (response.ok) {
                            return response.json();
                        } else {
                            throw new Error('ログイン失敗');
                        }
                    }).then(data => {
                        setUserData(data.username, data.userId);
                        updateMenu(true);
                        Swal.fire('ログイン成功', '', 'success');
                    }).catch(error => {
                        console.log("********************************************");                        
                        console.log(error);
                        Swal.fire('ユーザーIDまたはメールアドレスが違います', '', 'error');
                    });
                }
            });
        });
        

    registerLink.addEventListener('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: '新規登録',
            html: `
                <input type="text" id="account" class="swal2-input" placeholder="お名前">
                <input type="email" id="email" class="swal2-input" placeholder="メールアドレス">
                <input type="email" id="confirmEmail" class="swal2-input" placeholder="メールアドレス再入力">
            `,
            focusConfirm: false,
            didOpen: () => {
                const emailInput = Swal.getPopup().querySelector('#email');
                const confirmEmailInput = Swal.getPopup().querySelector('#confirmEmail');
    
                // 半角英数字のみを許可するためのリアルタイムバリデーション
                emailInput.addEventListener('input', function() {
                    // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                    this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
                });
    
                confirmEmailInput.addEventListener('input', function() {
                    // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                    this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
                });
            },
            preConfirm: () => {
                const account = document.getElementById('account').value;
                const email = document.getElementById('email').value;
                const confirmEmail = document.getElementById('confirmEmail').value;

                if (!email || !account) {
                    Swal.showValidationMessage('ユーザー名とメールアドレスを入力してください');
                    return false;
                }
                
                if (email !== confirmEmail) {
                    Swal.showValidationMessage('メールアドレスが一致しません');
                    return false;
                }

                return { account, email };
            },
            showCancelButton: true,
            confirmButtonText: '新規登録',
            cancelButtonText: 'キャンセル'
        }).then((result) => {
            if (result.isConfirmed) {
                const { account, email } = result.value;

                Swal.fire({
                    title: '登録中',
                    allowOutsideClick: false,
                    onBeforeOpen: () => {
                        Swal.showLoading();
                    }
                });

                fetch('/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ account, email })
                }).then(response => {
                    console.log(response)
                    if (response.ok) {
                        Swal.fire('登録完了', '新規登録が完了しました。メールを確認してください。', 'success');
                    } else {
                        Swal.fire('エラー', '登録中にエラーが発生しました', 'error');
                    }
                });
            }
        });
    });

    logoutLink.addEventListener('click', function(event) {
        event.preventDefault();
        fetch('/logout', {
            method: 'POST' // POSTメソッドでリクエストを送信
        })
        .then(response => {
            if (response.ok) {
                return response//.json(); // レスポンスをJSON形式で取得
            } else {
                throw new Error('ログアウト失敗');
            }
        })
        .then(data => {
            Swal.fire('ログアウト成功', '', 'success');
            window.location.reload(); // ページをリロードしてログイン状態を反映させる
        })
        .catch(error => {
            Swal.fire('ログアウトに失敗しました', '', 'error');
        });
    });

    hamburgerMenu.addEventListener('click', function() {
        if (isMenuOpen) {
            menu.classList.remove('show');
            hamburgerMenu.classList.remove('rotate');
            setTimeout(() => {
                menu.style.display = 'none';
            }, 300);
        } else {
            menu.style.display = 'block';
            setTimeout(() => {
                menu.classList.add('show');
                hamburgerMenu.classList.add('rotate');
            }, 10);
        }
        isMenuOpen = !isMenuOpen;
    });

    document.addEventListener('click', function(event) {
        if (!menu.contains(event.target) && event.target !== hamburgerMenu) {
            if (isMenuOpen) {
                menu.classList.remove('show');
                hamburgerMenu.classList.remove('rotate');
                setTimeout(() => {
                    menu.style.display = 'none';
                }, 300);
                isMenuOpen = false;
            }
        }
    });
});
document.getElementById('user-password').addEventListener('click', function(event) {
    event.preventDefault();
    Swal.fire({
        title: 'パスワード変更',
        html: `
            <input type="password" id="current-password" class="swal2-input" placeholder="現在のパスワード">
            <input type="password" id="new-password" class="swal2-input" placeholder="新しいパスワード">
            <input type="password" id="confirm-new-password" class="swal2-input" placeholder="新しいパスワード再入力">
        `,
        showCancelButton: true,
        confirmButtonText: '変更',
        cancelButtonText: 'キャンセル',
        didOpen: () => {
            const currentPasswordInput = Swal.getPopup().querySelector('#current-password');
            const newPasswordInput = Swal.getPopup().querySelector('#new-password');
            const confirmNewPasswordInput = Swal.getPopup().querySelector('#confirm-new-password');

            // 半角英数字のみを許可するためのリアルタイムバリデーション
            currentPasswordInput.addEventListener('input', function() {
                // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
            });

            newPasswordInput.addEventListener('input', function() {
                // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
            });

            confirmNewPasswordInput.addEventListener('input', function() {
                // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
            });
        },
            
        preConfirm: () => {
            const currentPassword = Swal.getPopup().querySelector('#current-password').value;
            const newPassword = Swal.getPopup().querySelector('#new-password').value;
            const confirmNewPassword = Swal.getPopup().querySelector('#confirm-new-password').value;

            if (!currentPassword || !newPassword || !confirmNewPassword) {
                Swal.showValidationMessage('すべてのフィールドを入力してください');
                return false;
            }

            if (newPassword !== confirmNewPassword) {
                Swal.showValidationMessage('新しいパスワードが一致しません');
                return false;
            }

            return { currentPassword, newPassword };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const { currentPassword, newPassword } = result.value;

            fetch('/update-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ currentPassword, newPassword })
            }).then(response => {
                if (response.ok) {
                    Swal.fire('パスワード変更成功', '', 'success');
                } else if(response.status == 401) {
                    Swal.fire('現在のパスワードが正しくありません', '', 'error');
                } else {
                    Swal.fire('パスワード変更失敗', '', 'error');
                }
            });
        }
    });
});

document.getElementById('user-info-link').addEventListener('click', function(event) {
    event.preventDefault();

    // ログインしているユーザーの情報を取得
    fetch('/check-login')
        .then(response => response.json())
        .then(data => {
        const currentUsername = data.username;
        const currentEmail = data.email;
        Swal.fire({
            title: 'ユーザー情報変更',
            html: `
                <input type="text" id="new-username" class="swal2-input" placeholder="新しいユーザー名" value="${currentUsername}">
                <input type="email" id="new-email" class="swal2-input" placeholder="新しいメールアドレス" value="${currentEmail}">
                <input type="email" id="confirm-new-email" class="swal2-input" placeholder="新しいメールアドレス再入力" value="${currentEmail}">
            `,
            showCancelButton: true,
            confirmButtonText: '変更',
            cancelButtonText: 'キャンセル',
            didOpen: () => {
                const emailInput = Swal.getPopup().querySelector('#new-email');
                const confirmEmailInput = Swal.getPopup().querySelector('#confirm-new-email');
    
                // 半角英数字のみを許可するためのリアルタイムバリデーション
                emailInput.addEventListener('input', function() {
                    // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                    this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
                });
    
                confirmEmailInput.addEventListener('input', function() {
                    // this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
                    this.value = this.value.replace(/[^a-zA-Z0-9\p{P}]/gu, '');
                });
            },
            preConfirm: () => {
                const newUsername = Swal.getPopup().querySelector('#new-username').value;
                const newEmail = Swal.getPopup().querySelector('#new-email').value;
                const confirmNewEmail = Swal.getPopup().querySelector('#confirm-new-email').value;

                if (!newUsername || !newEmail || !confirmNewEmail) {
                    Swal.showValidationMessage('すべてのフィールドを入力してください');
                    return false;
                }

                if (newEmail !== confirmNewEmail) {
                    Swal.showValidationMessage('メールアドレスが一致しません');
                    return false;
                }

                return { newUsername, newEmail };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const { newUsername, newEmail } = result.value;

                fetch('/update-user-info', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ newUsername, newEmail })
                }).then(response => {
                    if (response.ok) {
                        Swal.fire({
                            title: 'ユーザー情報変更成功',
                            icon: 'success',
                            showCancelButton: false,
                            confirmButtonText: 'OK'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.reload(); // ページを再読み込みする
                            }
                        });                            
                    } else {
                        Swal.fire('ユーザー情報変更失敗', '', 'error');
                    }
                });
            }
        });
    });
});
