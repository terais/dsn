document.getElementById('submitButton').addEventListener('click', function() {
    
    const selectedStores = document.querySelectorAll('input[name="selectedStore"]:checked');
    const selectedStoreIds = Array.from(selectedStores).map(store => store.value);

    if (selectedStoreIds.length === 0) {
        Swal.fire({
            icon: 'error',
            title: 'エラー',
            text: '少なくとも1つの店舗を選択してください。'
        });
        return;
    }

    const now = new Date();
    const currentHour = now.getHours();

    // 時間指定の選択肢を生成
    const timeSelectOptions = [];
    for (let hour = currentHour; hour <= 24; hour++) {
        if (hour === 24) {
            timeSelectOptions.push({
                value: '24later',
                label: '24時以降'
            });
        } else {
            timeSelectOptions.push({
                value: hour.toString(),
                label: hour.toString() + ':00～'
            });
        }
    }
    Swal.fire({
        title: '条件指定',
        html: `
        <div style="display: flex; align-items: center;">
            <label for="time-select">時間</label>
            <select id="time-select" class="swal2-input">
                ${timeSelectOptions.map(option => `<option value="${option.value}">${option.label}</option>`).join('')}
            </select>
        </div>
        <div style="display: flex; align-items: center;">
            <label for="guest-number">人数</label>
            <select id="guest-number" class="swal2-input">
                    <option value="1people">1人</option>
                    <option value="2people">2人</option>
                    <option value="3people">3人</option>
                    <option value="4people">4人</option>
                    <option value="5people">5人</option>
                    <option value="6people">6人</option>
                    <option value="7people">7人</option>
                    <option value="8people">8人</option>
                    <option value="9people">9人</option>
                    <option value="over10">10人以上</option>
            </select>
        </div>
        <div style="display: flex; align-items: center;">
            <label for="budget-select">予算</label>
            <select id="budget-select" class="swal2-input">
                <option value="unspecified">指定無し</option>
                <option value="under1000">1,000円未満</option>
                <option value="1000to2000">1,000円～2,000円</option>
                <option value="2000to3000">2,000円～3,000円</option>
                <option value="3000to4000">3,000円～4,000円</option>
                <option value="4000to5000">4,000円～5,000円</option>
                <option value="5000to6000">5,000円～6,000円</option>
                <option value="6000to7000">6,000円～7,000円</option>
                <option value="7000to8000">7,000円～8,000円</option>
                <option value="8000to9000">8,000円～9,000円</option>
                <option value="9000to10000">9,000円～10,000円</option>
                <option value="over10000">10,000円以上</option>
            </select>
        </div>
        <label><input type="checkbox" id="smoking-checkbox">喫煙可</label>
        <label><input type="checkbox" id="alcohol-checkbox">お酒の提供</label>
        `,
        showCancelButton: true,
        confirmButtonText: '送信',
        cancelButtonText: 'キャンセル',
        preConfirm: () => {
            const time = document.getElementById('time-select').value;
            const guestNumber = document.getElementById('guest-number').value;
            const budget = document.getElementById('budget-select').value;
            const smokingAllowed = document.getElementById('smoking-checkbox').checked;
            const alcohol = document.getElementById('alcohol-checkbox').checked;

            // 本来の送信ボタンの処理を呼び出す
            submitData(time, guestNumber, budget, smokingAllowed, alcohol);
        }
    });
});

function submitData(time, guestNumber, budget, smokingAllowed, alcohol) {
    const userId = document.getElementById('userId').textContent;
    const selectedStores = document.querySelectorAll('input[name="selectedStore"]:checked');
    const selectedStoreIds = Array.from(selectedStores).map(store => store.value);

    const data = {
        userId: userId,
        selectedStoreIds: selectedStoreIds,
        time: time,
        guestNumber: guestNumber,
        budget: budget,
        smokingAllowed: smokingAllowed,
        alcohol: alcohol
    };

    Swal.fire({
        title: '送信中',
        allowOutsideClick: false,
        onBeforeOpen: () => {
            Swal.showLoading();
        }
    });

    fetch('/api/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response//.json();
    })
    .then(responseData => {
        Swal.fire({
            icon: 'success',
            title: '送信完了',
            text: '店舗情報が送信されました。'
        });
    })
    .catch(error => {
        console.error('Error submitting data:', error);
        Swal.fire({
            icon: 'error',
            title: 'エラー',
            text: 'データの送信中にエラーが発生しました。'
        });
    });
}

