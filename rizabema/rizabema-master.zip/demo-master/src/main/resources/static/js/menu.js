document.addEventListener('DOMContentLoaded', function() {
    const hamburgerMenu = document.getElementById('hamburger-menu');
    const menu = document.getElementById('menu');

    hamburgerMenu.addEventListener('click', function() {
        if (menu.classList.contains('show')) {
            menu.classList.remove('show');
            setTimeout(() => {
                menu.style.display = 'none';
            }, 300); // アニメーションの時間と合わせる
            hamburgerMenu.classList.remove('rotate');
        } else {
            menu.style.display = 'block';
            setTimeout(() => {
                menu.classList.add('show');
            }, 10); // アニメーションをスムーズに始めるための微小な遅延
            hamburgerMenu.classList.add('rotate');
        }
    });

    // メニュー外をクリックしたときにメニューを閉じる
    document.addEventListener('click', function(event) {
        if (!menu.contains(event.target) && event.target !== hamburgerMenu) {
            menu.classList.remove('show');
            setTimeout(() => {
                menu.style.display = 'none';
            }, 300); // アニメーションの時間と合わせる
            hamburgerMenu.classList.remove('rotate');
        }
    });
});