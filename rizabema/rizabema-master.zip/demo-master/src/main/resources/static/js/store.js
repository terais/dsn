function clearForm() {
    document.querySelector('form').reset();
}


function showCreateForm() {
    Swal.fire({
        title: '新規ストアの作成',
        html: `
            <form id="createStoreForm">
                <div class="form-group">
                    <label for="storeId">Store ID:</label>
                    <input type="text" id="storeId" class="swal2-input" placeholder="Store ID" style="width: 95%">
                </div>
                <div class="form-group">
                    <label for="storeName">Store Name:</label>
                    <input type="text" id="storeName" class="swal2-input" placeholder="Store Name" style="width: 95%">
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" id="address" class="swal2-input" placeholder="Address" style="width: 95%">
                </div>
                <div class="form-group">
                    <label for="notes">Notes:</label>
                    <textarea id="notes" class="swal2-textarea" placeholder="Notes" style="width: 95%"></textarea>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" class="swal2-input" placeholder="Email" style="width: 95%">
                </div>
                <div class="form-group">
                    <label for="phoneNumber">Phone Number:</label>
                    <input type="text" id="phoneNumber" class="swal2-input" placeholder="Phone Number" style="width: 95%">
                </div>
            </form>
        `,
        showCancelButton: true,
        confirmButtonText: '作成',
        cancelButtonText: 'キャンセル',
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#dc3545',
        preConfirm: () => {
            const storeId = document.getElementById('storeId').value.trim();
            const storeName = document.getElementById('storeName').value.trim();
            const address = document.getElementById('address').value.trim();
            const notes = document.getElementById('notes').value.trim();
            const email = document.getElementById('email').value.trim();
            const phoneNumber = document.getElementById('phoneNumber').value.trim();
            const userId = document.getElementById('userId').textContent.trim();

            if (!storeId || !storeName || !address || !email) {
                Swal.showValidationMessage('すべての必須フィールドに入力してください。');
                return false;
            }

            // 存在チェック
            return fetch(`/store/exists?storeId=${encodeURIComponent(storeId)}`)
                .then(response => response.json())
                .then(exists => {
                    if (exists) {
                        Swal.showValidationMessage('このStore IDは既に存在します。');
                        return false;
                    }
                    return {
                        storeId,
                        storeName,
                        address,
                        notes,
                        email,
                        phoneNumber,
                        userId
                    };
                });
        }
    }).then((result) => {
        if (result.isConfirmed) {
            console.log('新規ストアデータ:', result.value);

            fetch('/store/create', {
                method: 'POST',
                body: new URLSearchParams(result.value),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            .then(response => response)
            .then(data => {
                console.log('成功:', data)
                Swal.fire('登録しました', '', 'success')
                    .then(() => {
                        location.reload(); // テーブルを再読み込み
                    });
            })
            .catch(error => {
                console.error('エラー:', error);
                Swal.fire('失敗しました', '', 'error');
            });
        }
    });
}

function showUpdateForm(buttonElement) {
    const storeId = buttonElement.getAttribute('data-store-id');
    const userId = buttonElement.getAttribute('data-user-id');
    console.log(storeId);
    console.log(userId);
    // 店舗情報の取得
    fetch(`/store/update?storeId=${storeId}&userId=${userId}`, {
                method: 'GET'
            })
        .then(response => response.json())
        .then(store => {
            Swal.fire({
                title: 'ストア情報の更新',
                html: `
                    <form id="updateStoreForm">
                        <div class="form-group">
                            <label for="updateStoreId">Store ID:</label>
                            <input type="text" id="updateStoreId" class="swal2-input" value="${store.storeId}" readonly style="width: 95%">
                        </div>
                        <div class="form-group">
                            <label for="updateStoreName">Store Name:</label>
                            <input type="text" id="updateStoreName" class="swal2-input" value="${store.storeName}" style="width: 95%">
                        </div>
                        <div class="form-group">
                            <label for="updateAddress">Address:</label>
                            <input type="text" id="updateAddress" class="swal2-input" value="${store.address}" style="width: 95%">
                        </div>
                        <div class="form-group">
                            <label for="updateNotes">Notes:</label>
                            <textarea id="updateNotes" class="swal2-textarea" style="width: 95%">${store.notes}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="updateEmail">Email:</label>
                            <input type="email" id="updateEmail" class="swal2-input" value="${store.email}" style="width: 95%">
                        </div>
                        <div class="form-group">
                            <label for="updatePhoneNumber">Phone Number:</label>
                            <input type="text" id="updatePhoneNumber" class="swal2-input" value="${store.phoneNumber}" style="width: 95%">
                        </div>
                    </form>
                `,
                showCancelButton: true,
                confirmButtonText: '更新',
                cancelButtonText: 'キャンセル',
                confirmButtonColor: '#007bff',
                cancelButtonColor: '#dc3545',
                preConfirm: () => {
                    const storeId = document.getElementById('updateStoreId').value.trim();
                    const storeName = document.getElementById('updateStoreName').value.trim();
                    const address = document.getElementById('updateAddress').value.trim();
                    const notes = document.getElementById('updateNotes').value.trim();
                    const email = document.getElementById('updateEmail').value.trim();
                    const phoneNumber = document.getElementById('updatePhoneNumber').value.trim();
                    
                    if (!storeName || !address || !email) {
                        Swal.showValidationMessage('すべての必須フィールドに入力してください。');
                        return false;
                    }
                    
                    return {
                        storeId,
                        storeName,
                        address,
                        notes,
                        email,
                        phoneNumber,
                        userId
                    };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('/store/update', {
                        method: 'POST',
                        body: new URLSearchParams(result.value),
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        }
                    })
                    .then(response => response)
                    .then(data => {
                        console.log('更新成功:', data);
                        Swal.fire('更新しました', '', 'success')
                            .then(() => {
                                location.reload(); // テーブルを再読み込み
                            });
                    })
                    .catch(error => {
                        console.error('更新エラー:', error);
                        Swal.fire('更新失敗', '', 'error');
                    });
                }
            });
        })
        .catch(error => {
            console.error('情報取得エラー:', error);
            Swal.fire('情報取得失敗', '', 'error');
        });
}

function deleteStore(buttonElement) {
    const storeId = buttonElement.getAttribute('data-store-id');
    const userId = buttonElement.getAttribute('data-user-id');

    console.log(storeId);
    console.log(userId);

    Swal.fire({
        title: '削除の確認',
        text: `${storeId} を削除しますか？`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '削除',
        cancelButtonText: 'キャンセル'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`/store/delete?storeId=${storeId}&userId=${userId}`, {
                method: 'DELETE'
            })
            .then(response => response)
            .then(data => {
                console.log('削除成功:', data);
                Swal.fire('削除しました', '', 'success')
                    .then(() => {
                        location.reload(); // テーブルを再読み込み
                    });
            })
            .catch(error => {
                console.error('削除エラー:', error);
                Swal.fire('削除失敗', '', 'error');
            });
        }
    });
}