function loadMapScript() {
    var googleMapsApiKey = document.getElementById('googleMapsApiKey').textContent;
    var script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${googleMapsApiKey}&libraries=places&callback=initMap`;
    script.async = false;
    script.defer = false;
    document.head.appendChild(script);
}
window.onload = loadMapScript;

let currentPosition = [];
let myself = null;
let markers = [];
let isCurrent = true;
let lastSearchPosition = null;
let circle;
let markerData = []; // 空の配列で初期化
let map;
let currentInfoWindow = null;

async function initMap() {
    const savedCenter = localStorage.getItem('mapCenter');
    const savedZoom = localStorage.getItem('mapZoom');
    const mapLatLng = savedCenter ? JSON.parse(savedCenter) : { lat: 35.668590551468256, lng: 139.76253328771452 };
    const zoomLevel = savedZoom ? parseInt(savedZoom) : 15;

    map = new google.maps.Map(document.getElementById('map'), {
        center: mapLatLng,
        zoom: zoomLevel,
        mapTypeControl: true,
        mapTypeControlOptions: {
            position: google.maps.ControlPosition.BOTTOM_LEFT
        }
    });

    map.addListener('center_changed', () => {
        const center = map.getCenter();
        localStorage.setItem('mapCenter', JSON.stringify({ lat: center.lat(), lng: center.lng() }));
        showMarkersWithinCircle(center, circle.getRadius());
    });

    map.addListener('zoom_changed', () => {
        localStorage.setItem('mapZoom', map.getZoom());
    });

    const input = document.getElementById('search-box');
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(input);

    const searchBox = new google.maps.places.SearchBox(input);
    searchBox.addListener('places_changed', function() {
        const places = searchBox.getPlaces();
        if (places.length === 0) return;

        clearMarkers(); // 既存のマーカーをクリアする

        const bounds = new google.maps.LatLngBounds();
        places.forEach(place => {
            if (!place.geometry || !place.geometry.location) return;

            const newMarker = new google.maps.Marker({
                map: map,
                title: place.name,
                position: place.geometry.location,
                icon: { url: 'img/human.png', scaledSize: new google.maps.Size(40, 40) }
            });
            markers.push(newMarker);
            bounds.extend(place.geometry.location);
        });
        map.fitBounds(bounds);
        map.setZoom(15);

        if (circle) {
            circle.setCenter(bounds.getCenter());
        }

        lastSearchPosition = bounds.getCenter();
        showMarkersWithinCircle(bounds.getCenter(), circle.getRadius());
    });

    circle = new google.maps.Circle({
        strokeColor: '#00ffff',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#00ffff',
        fillOpacity: 0.35,
        map: map,
        center: mapLatLng,
        radius: 200,
        clickable: false
    });

    const locationButton = document.createElement('button');
    locationButton.classList.add('custom-map-control-button');
    locationButton.textContent = '📍';
    map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(locationButton);
    locationButton.addEventListener('click', function() {
        isCurrent = true;
        showLoadingIndicator();
        getCurrentLocation();
        map.setZoom(15);
    });

    function success(position) {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
    
        const pos = { lat: latitude, lng: longitude };
        if (isCurrent) {
            currentPosition = pos;
            if (myself) {
                myself.setMap(null);
            }
            myself = new google.maps.Marker({
                position: pos,
                map: map,
                title: '現在位置',
                icon: { url: 'img/human.png', scaledSize: new google.maps.Size(40, 40) }
            });
    
            markers.push(myself);
            map.setCenter(pos);
            circle.setCenter(pos);
            lastSearchPosition = null;
            showMarkersWithinCircle(pos, circle.getRadius());
        }
        hideLoadingIndicator();
    }

    function error(err) {
        console.error(err)
        document.getElementById('status').textContent = `Error: ${err.message}`;
        hideLoadingIndicator();
    }

    function getCurrentLocation() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(success, error, { enableHighAccuracy: true });
        } else {
            document.getElementById('status').textContent = 'Geolocation is not supported by your browser';
        }
    }

    async function fetchMarkerData() {
        try {
            const response = await fetch('/api/markers');
            console.log("***************************")
            console.log(response)
            console.log(response.ok)
            console.log(response.json)
            console.log("---------------------------")
            if (!response.ok) throw new Error('Network response was not ok');
            markerData = await response.json();
            showMarkersWithinCircle(map.getCenter(), circle.getRadius());
            displayMarkerData(); 
        } catch (error) {
            console.error('Failed to fetch marker data:', error);
        }
    }

    const toggleButton = document.getElementById('toggleMarkerDataButton');
    toggleButton.textContent = '店舗一覧 ▼';

    map.controls[google.maps.ControlPosition.TOP_LEFT].push(toggleButton);

    toggleButton.style.display = 'none';

    toggleButton.addEventListener('click', function() {
        const markerDataDisplay = document.getElementById('markerDataDisplay');
        if (markerDataDisplay.style.display === 'none') {
            markerDataDisplay.style.display = 'block';
            toggleButton.textContent = '店舗一覧 ▼'; // 表示時のテキスト
        } else {
            markerDataDisplay.style.display = 'none';
            toggleButton.textContent = '店舗一覧 ▶'; // 非表示時のテキスト
        }
    });

    fetchMarkerData();

    function displayMarkerData(filteredMarkerData) {
        const markerDataDisplay = document.getElementById('markerDataDisplay');
        if (!markerDataDisplay) return;
    
        markerDataDisplay.innerHTML = ''; // 既存のコンテンツをクリア
        if(filteredMarkerData != null) {
            filteredMarkerData.forEach(data => {
                const markerDiv = document.createElement('div');
                markerDiv.classList.add('marker-item');
        
                const containerDiv = document.createElement('div');
                containerDiv.classList.add('store-container');
        
                const storeIdPara = document.createElement('p');
                containerDiv.appendChild(storeIdPara);
        
                const storeNamePara = document.createElement('p');
                storeNamePara.textContent = `店舗名: ${data.storeName}`;
                containerDiv.appendChild(storeNamePara);
        
                const addressPara = document.createElement('p');
                addressPara.textContent = `住所: ${data.address}`;
                containerDiv.appendChild(addressPara);

                const notesPara = document.createElement('p');
                notesPara.textContent = data.notes ? `特記事項: ${data.notes}` : '';
                containerDiv.appendChild(notesPara);
        
                const checkboxContainer = document.createElement('div');
                checkboxContainer.classList.add('checkbox-container');
                const label = document.createElement('label');
                label.classList.add('checkbox-label');
                label.textContent = '送信する';
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.classList.add('custom-checkbox');
                checkbox.name = 'selectedStore';
                checkbox.value = data.storeId;
        
                checkboxContainer.appendChild(label);
                checkboxContainer.appendChild(checkbox);
        
                containerDiv.appendChild(checkboxContainer);
        
                markerDiv.appendChild(containerDiv);
                markerDataDisplay.appendChild(markerDiv);
            });
        }
    
        // "すべてをチェックする" チェックボックスの追加
        const selectAllCheckbox = document.createElement('input');
        selectAllCheckbox.type = 'checkbox';
        selectAllCheckbox.id = 'selectAllCheckbox';
        selectAllCheckbox.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('input[name="selectedStore"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
    
        const selectAllLabel = document.createElement('label');
        selectAllLabel.textContent = 'すべてをチェックする';
        selectAllLabel.setAttribute('for', 'selectAllCheckbox');
    
        markerDataDisplay.insertBefore(selectAllCheckbox, markerDataDisplay.firstChild);
        markerDataDisplay.insertBefore(selectAllLabel, markerDataDisplay.firstChild);
    }    

    map.addListener('click', function(event) {
        const clickedLocation = event.latLng;
        map.setCenter(clickedLocation);
        circle.setCenter(clickedLocation);
        showMarkersWithinCircle(clickedLocation, circle.getRadius());
    });

    let displayedMarkers = markerData;
    async function showMarkersWithinCircle(center, radius) {
        const markersInRange = []; // 範囲内のマーカーを保存する配列
        circle.setCenter(center);

        displayedMarkers.forEach(marker => marker.setMap(null));
        displayedMarkers = [];

        for (const data of markerData) {
            try {
                const results = await geocodeAddress(data.address);
                if (results) {
                    
                    const location = results[0].geometry.location;
                    const distance = google.maps.geometry.spherical.computeDistanceBetween(center, location);
                    
                    if (distance <= radius) {
                        const newMarker = new google.maps.Marker({
                            position: location,
                            map: map
                        });
                        markers.push(newMarker);
                        
                        newMarker.addListener('click', function() {
                            if (currentInfoWindow) {
                                currentInfoWindow.close();
                            }
                            currentInfoWindow = new google.maps.InfoWindow({
                                content: `
                                    <div class="info-window-content">
                                        <h3>${data.storeName}</h3>
                                        <p><strong>住所:</strong> ${data.address}</p>
                                        <p><strong>電話番号:</strong> ${data.phoneNumber || '情報なし'}</p>
                                        <p><strong>備考:</strong> ${data.notes || '情報なし'}</p>
                                    </div>
                                `
                            });
                            currentInfoWindow.open(map, newMarker);
                        });
                        markersInRange.push(data); // 範囲内のデータを保存
                        displayedMarkers.push(newMarker); // 表示中のマーカーとして追加
                    }
                }
            } catch (error) {
                if (error == 'Geocode was not successful for the following reason: ZERO_RESULTS') {
                    console.warn(error);
                } else {
                    console.error(error);
                }
            }

            // 範囲内のマーカーだけを表示する
            displayMarkerData(markersInRange);
        }
                
        function geocodeAddress(address) {
            return new Promise((resolve, reject) => {
                const geocoder = new google.maps.Geocoder();
                geocoder.geocode({ address: address }, (results, status) => {
                    if (status === 'OK') {
                        resolve(results);
                    } else {
                        reject('Geocode was not successful for the following reason: ' + status);
                    }
                });
            });
        }
    
        // 範囲内のマーカーだけを表示する
        displayMarkerData(markersInRange);
    }


    fetchMarkerData();
    getCurrentLocation();
}

function clearMarkers() {
    markers.forEach(marker => {
        if (marker !== myself) {
            marker.setMap(null);
        }
    });
    markers = [myself].filter(Boolean);
}

function showLoadingIndicator() {
    const element = document.getElementById('loading-container');
    if (element) {
        element.style.display = 'block';
    }    
}

function hideLoadingIndicator() {
    const element = document.getElementById('loading-container');
    if (element) {
        element.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (!map) {
        initMap();
    } else if (lastSearchPosition) {
        map.setCenter(lastSearchPosition);
        if (circle) {
            circle.setCenter(lastSearchPosition);
        }
        showMarkersWithinCircle(lastSearchPosition, circle.getRadius());
    }
});
