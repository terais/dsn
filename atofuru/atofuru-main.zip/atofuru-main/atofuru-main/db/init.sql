-- Create schema if not exists
CREATE SCHEMA IF NOT EXISTS dsn;

DELETE FROM dsn.user_base64_rel;
DROP TABLE IF EXISTS dsn.user_base64_rel;
DELETE FROM dsn.receipt_info;
DROP TABLE IF EXISTS dsn.receipt_info;
DELETE FROM dsn.purchase_info;
DROP TABLE IF EXISTS dsn.purchase_info;
DELETE FROM dsn.users;
DROP TABLE IF EXISTS dsn.users;
DELETE FROM dsn.job_master;
DROP TABLE IF EXISTS dsn.job_master;
DELETE FROM dsn.income_master;
DROP TABLE IF EXISTS dsn.income_master;
DELETE FROM dsn.gender_master;
DROP TABLE IF EXISTS dsn.gender_master;
DELETE FROM dsn.util_master;
DROP TABLE IF EXISTS dsn.util_master;

-- Create job master table
CREATE TABLE IF NOT EXISTS dsn.job_master (
    job_code VARCHAR(5) PRIMARY KEY,
    job_name VARCHAR(255) NOT NULL,
    valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP
);

-- Create income master table
CREATE TABLE IF NOT EXISTS dsn.income_master (
    income_code VARCHAR(5) PRIMARY KEY,
    income_range VARCHAR(255) NOT NULL,
    valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP
);

-- Create gender master table
CREATE TABLE IF NOT EXISTS dsn.gender_master (
    gender_code VARCHAR(5) PRIMARY KEY,
    gender_name VARCHAR(10) NOT NULL,
    valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP
);

-- Create users table with users
CREATE TABLE IF NOT EXISTS dsn.users (
    user_id SERIAL PRIMARY KEY,
	login_id VARCHAR(255) UNIQUE NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    first_name VARCHAR(255) NOT NULL,
    last_name_kana VARCHAR(255) NOT NULL,
    first_name_kana VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    birth_date DATE NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20),
    job_code VARCHAR(5) REFERENCES dsn.job_master(job_code),
    income_code VARCHAR(5) REFERENCES dsn.income_master(income_code),
    gender_code VARCHAR(5) REFERENCES dsn.gender_master(gender_code),
    valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP
);

-- Create users table with user_base64_rel
CREATE TABLE IF NOT EXISTS dsn.user_base64_rel (
	user_id VARCHAR(255) UNIQUE NOT NULL REFERENCES dsn.users(login_id), 
	my_number_card_base64_1 text,
	my_number_card_base64_2 text,
	id_card_base64_1 text,
	id_card_base64_2 text,
	valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP,
	PRIMARY KEY(user_id)
);

-- Create users table with purchase_info
CREATE TABLE IF NOT EXISTS dsn.receipt_info (
    receipt_id SERIAL NOT NULL UNIQUE,
    login_id VARCHAR(255) NOT NULL REFERENCES dsn.users(login_id), 
    purchase_date TIMESTAMP NOT NULL,
    purchase_store VARCHAR(255) NOT NULL,
    purchase_address VARCHAR(255) NOT NULL,
    purchase_phone VARCHAR(255) NOT NULL,
    total_amount INTEGER NOT NULL,
    receipt_base64 text,
    valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP,
    PRIMARY KEY(receipt_id, login_id)
);

-- Create users table with purchase_info
CREATE TABLE IF NOT EXISTS dsn.purchase_info (
    purchase_id SERIAL,
    receipt_id INTEGER NOT NULL,
    login_id VARCHAR(255) NOT NULL REFERENCES dsn.users(login_id), 
    commodity VARCHAR(255) NOT NULL,
    purchase_amount INTEGER NOT NULL,
    valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP,
    PRIMARY KEY(purchase_id, receipt_id, login_id)
);

-- Create users table with util_master
CREATE TABLE IF NOT EXISTS dsn.util_master (
	system_key_1 VARCHAR(255) not null,
	system_key_2 VARCHAR(255) not null,
	value VARCHAR(255) not null,
	valid_from DATE,
    valid_to DATE,
    created_by VARCHAR(255),
    created_at TIMESTAMP,
    updated_by VARCHAR(255),
    updated_at TIMESTAMP,
	PRIMARY KEY(system_key_1, system_key_2)
);

-- Insert test data into job_master table
INSERT INTO dsn.job_master (job_code, job_name, valid_from, valid_to, created_by, created_at, updated_by, updated_at) VALUES
('JO001', '指定無し', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('JO002', '正社員', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('JO003', '非正規社員', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('JO004', 'アルバイト・パート', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('JO005', '自営業', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('JO006', 'その他', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP);

-- Insert test data into income_master table
INSERT INTO dsn.income_master (income_code, income_range, valid_from, valid_to, created_by, created_at, updated_by, updated_at) VALUES
('IN001', '指定無し', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN002', '0～399万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN003', '400万～499万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN004', '500万～599万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN005', '600万～699万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN006', '700万～799万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN007', '800万～899万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN008', '900万～999万', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN009', '1000万以上', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('IN010', 'その他', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP);

-- Insert test data into gender_master table
INSERT INTO dsn.gender_master (gender_code, gender_name, valid_from, valid_to, created_by, created_at, updated_by, updated_at) VALUES
('GE001', '指定無し', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('GE002', '男性', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP),
('GE003', '女性', NULL, NULL, 'system', CURRENT_TIMESTAMP, 'system', CURRENT_TIMESTAMP);

-- Insert test data into util_master table
INSERT INTO dsn.util_master (system_key_1, system_key_2, value, valid_from, valid_to, created_by, created_at, updated_by, updated_at) VALUES 
('system', 'project.url', 'https://192.168.0.104:8443', NULL, NULL, NULL, NULL, NULL, NULL);

GRANT USAGE ON SCHEMA dsn TO dsn;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA dsn TO dsn;
GRANT USAGE, SELECT ON SEQUENCE dsn.users_user_id_seq TO dsn;
GRANT USAGE, SELECT ON SEQUENCE dsn.receipt_info_receipt_id_seq TO dsn;
GRANT USAGE, SELECT ON SEQUENCE dsn.purchase_info_purchase_id_seq TO dsn;

/*
INSERT INTO dsn.users (
    login_id, 
    last_name, 
    first_name, 
    last_name_kana, 
    first_name_kana, 
    email, 
    password, 
    birth_date, 
    postal_code, 
    address, 
    phone_number, 
    job_code, 
    income_code, 
    gender_code, 
    valid_from, 
    valid_to, 
    created_by, 
    created_at, 
    updated_by, 
    updated_at
) VALUES (
    'fe75dae12d', 
    '寺居', 
    '滋', 
    'テライ', 
    'シゲル', 
    'ykhmmsugv@gmail.com', 
    '$2a$10$MYQOhXRWbOu4nHrYuZl6cOw.BVahnulcKVbFmRNJkNdDQVqx/K9pe', 
    '1979-01-15', 
    '272-0144', 
    '千葉県 市川市 新井', 
    '0311111111', 
    'JO002', 
    'IN002', 
    'GE002', 
    NULL, 
    NULL, 
    NULL, 
    NULL, 
    NULL, 
    NULL
);

-- Insert data into receipt_info
INSERT INTO dsn.receipt_info (
    login_id, 
    purchase_date, 
    purchase_store, 
    purchase_address, 
    purchase_phone, 
    total_amount, 
    valid_from, 
    valid_to, 
    created_by, 
    created_at, 
    updated_by, 
    updated_at
) VALUES
('fe75dae12d', '2024-08-28 10:15:00', 'コンビニエンスストアA', '千葉県 市川市 新井', '0311111111', 1500, '2024-08-28', '2024-09-28', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
('fe75dae12d', '2024-08-29 14:30:00', 'スーパーB', '千葉県 市川市 新井', '0311111111', 2500, '2024-08-29', '2024-09-29', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
('fe75dae12d', '2024-08-30 16:45:00', 'ドラッグストアC', '千葉県 市川市 新井', '0311111111', 3200, '2024-08-30', '2024-09-30', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP);

-- Insert data into purchase_info for receipt_id 1
INSERT INTO dsn.purchase_info (
    receipt_id, 
    login_id, 
    commodity, 
    purchase_amount, 
    valid_from, 
    valid_to, 
    created_by, 
    created_at, 
    updated_by, 
    updated_at
) VALUES
(1, 'fe75dae12d', '商品A', 500, '2024-08-28', '2024-09-28', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(1, 'fe75dae12d', '商品B', 1000, '2024-08-28', '2024-09-28', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(1, 'fe75dae12d', '商品C', 200, '2024-08-28', '2024-09-28', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(2, 'fe75dae12d', '商品D', 800, '2024-08-29', '2024-09-29', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(2, 'fe75dae12d', '商品E', 1200, '2024-08-29', '2024-09-29', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(2, 'fe75dae12d', '商品F', 500, '2024-08-29', '2024-09-29', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(3, 'fe75dae12d', '商品G', 1500, '2024-08-30', '2024-09-30', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(3, 'fe75dae12d', '商品H', 1200, '2024-08-30', '2024-09-30', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP),
(3, 'fe75dae12d', '商品I', 500, '2024-08-30', '2024-09-30', 'test_user', CURRENT_TIMESTAMP, 'test_user', CURRENT_TIMESTAMP);
*/