const video = document.getElementById('video');
const canvas = document.createElement('canvas');
const context = canvas.getContext('2d');
const captureButton = document.getElementById('capture');
const switchCameraButton = document.getElementById('switchCamera');

let currentFacingMode = 'environment'; // 初期設定は外側カメラ

window.addEventListener('message', (event) => {
    if (event.data && event.data.type) {
        sectionName = event.data.type;
        console.log('Received sectionName:', sectionName); // デバッグ用
    }
});

// カメラのストリームを取得してvideo要素に設定
function startCamera(facingMode) {
    navigator.mediaDevices.getUserMedia({
        video: { facingMode }
    })
    .then(stream => {
        video.srcObject = stream;
    })
    .catch(err => {
        console.error('カメラの起動に失敗しました', err);
    });
}

// 初期カメラ起動
startCamera(currentFacingMode);

// 撮影ボタンのクリックイベント
captureButton.addEventListener('click', () => {
    if (!sectionName) return;

    // canvasのサイズを設定
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // canvasにカメラのフレームを描画
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // canvasの内容をbase64文字列として取得
    const dataURL = canvas.toDataURL('image/png');

    // メインウィンドウにメッセージを送信
    window.opener.postMessage({
        image: dataURL,
        type: sectionName
    }, '*');
    // カメラウィンドウを閉じる
    window.close();
});

// カメラ切り替えボタンのクリックイベント
switchCameraButton.addEventListener('click', () => {
    // ストリームを停止してからカメラを切り替える
    const stream = video.srcObject;
    if (stream) {
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
    }
    
    // カメラの向きを切り替える
    currentFacingMode = (currentFacingMode === 'environment') ? 'user' : 'environment';
    startCamera(currentFacingMode);
});