document.addEventListener('DOMContentLoaded', function() {
    // セクションの初期化
    setupSection('identityImage', 'openFileDialog', 'openCamera', 'dropArea', 'fileList', 'identityImage', 'receiptBase64');
    const form = document.getElementById('registrationForm');
    form.addEventListener('submit', function(event) {
        const receiptBase64 = document.getElementById('receiptBase64').value;
        
        if (!receiptBase64) {
            alert('画像が選択されていません。画像をアップロードしてください。');
            event.preventDefault(); // フォームの送信をキャンセル
        }
    });
});

function setupSection(fileInputId, openFileDialogId, openCameraId, dropAreaId, fileListId, sectionName, hiddenFieldId) {

    const fileInput = document.getElementById(fileInputId);
    const openFileDialogButton = document.getElementById(openFileDialogId);
    const openCameraButton = document.getElementById(openCameraId);
    const dropArea = document.getElementById(dropAreaId);
    const fileList = document.getElementById(fileListId);
    const hiddenField = document.getElementById(hiddenFieldId);

    let imageArray = JSON.parse(hiddenField.value || "[]"); // 既存のBase64データを読み込む

    openCameraButton.addEventListener('click', () => {
        const cameraWindow = window.open('/register-camera', 'cameraWindow', 'width=800,height=600');
        window.name = sectionName; 
        cameraWindow.onload = function() {
            cameraWindow.postMessage({ type: sectionName }, '*');
        };
    });

    openFileDialogButton.addEventListener('click', () => {
        fileInput.value = ''; // 既存の選択ファイルをクリア
        fileInput.click();
    });

    fileInput.addEventListener('change', () => {
        handleFiles(); 
    });

    function handleFiles() {
        const files = Array.from(fileInput.files);
        if (files.length === 0) {
            console.log('No files selected.');
            return;
        }

        // 新しいファイルを処理
        files.forEach(file => {
            const reader = new FileReader();

            reader.onload = function(event) {
                // 既存の画像を削除
                fileList.innerHTML = ''; // ファイルリストをクリア
                imageArray = []; // 配列をリセット

                displayImage(event.target.result, file.name);
                imageArray.push(event.target.result); // 配列に追加
                hiddenField.value = JSON.stringify(imageArray); // hiddenフィールドに保存
            };

            reader.readAsDataURL(file);
        });
        fileInput.value = '';
    }

    dropArea.addEventListener('dragover', (event) => {
        event.preventDefault();
        event.stopPropagation();
        dropArea.classList.add('dragging');
    });

    dropArea.addEventListener('dragleave', () => {
        dropArea.classList.remove('dragging');
    });

    dropArea.addEventListener('drop', (event) => {
        event.preventDefault();
        event.stopPropagation();
        dropArea.classList.remove('dragging');

        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const newFileList = new DataTransfer();
            for (let i = 0; i < fileInput.files.length; i++) {
                newFileList.items.add(fileInput.files[i]);
            }
            for (let i = 0; i < files.length; i++) {
                newFileList.items.add(files[i]);
            }
            fileInput.files = newFileList.files;
            handleFiles();
        }
    });

    function displayImage(imageSrc, fileName) {
        // 画像を取得し、Blob に変換
        fetch(imageSrc)
            .then(response => response.blob())
            .then(blob => {

                fileList.innerHTML = '';

                // 新しく表示するファイル情報を作成
                const fileInfoDiv = document.createElement('div');

                const img = document.createElement('img');
                img.src = imageSrc;
                img.alt = fileName;

                // UI に追加
                fileInfoDiv.appendChild(img);
                fileList.appendChild(fileInfoDiv);
            });
    }

    window.addEventListener('message', (event) => {
        if (event.data.image) {
            if (event.data.type === sectionName) {
                const fileName = 'sample_0.jpg';
                displayImage(event.data.image, fileName);
                imageArray.push(event.data.image); 
                hiddenField.value = JSON.stringify(imageArray); // hiddenフィールドに保存
            }
        }
    });
}

function encodeImageFileAsURL(element, hiddenFieldId) {
    const file = element.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = function () {
            document.getElementById(hiddenFieldId).value = reader.result;
        };
        reader.readAsDataURL(file);
    }
}
