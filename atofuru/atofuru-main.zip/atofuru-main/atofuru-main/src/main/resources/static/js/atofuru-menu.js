
function redirectTo(url) {
    // Get userId from the hidden form
    var userId = document.getElementById('userIdField').value;

    // Construct the URL with query parameters
    var fullUrl = url + (url.includes('?') ? '&' : '?') + 'userId=' + encodeURIComponent(userId);

    // Set the action of the form and submit it
    document.getElementById('hiddenForm').action = fullUrl;
    document.getElementById('hiddenForm').submit();
}