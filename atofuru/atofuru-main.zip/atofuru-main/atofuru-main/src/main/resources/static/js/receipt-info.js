document.addEventListener('DOMContentLoaded', function() {
    const checkAllBox = document.getElementById('checkAll');
    const checkboxes = document.querySelectorAll('#productList input[type="checkbox"]');
    
    checkboxes.forEach(checkbox => checkbox.checked = true);
    checkAllBox.addEventListener('change', function() {
        checkboxes.forEach(checkbox => checkbox.checked = checkAllBox.checked);
    });
});
