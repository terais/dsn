
function generateDateOptions() {
    const yearSelect = document.getElementById('birthYear');
    const monthSelect = document.getElementById('birthMonth');
    const daySelect = document.getElementById('birthDay');

    // 現在の年を取得
    const currentYear = new Date().getFullYear();

    // Controllerから取得した値を設定（デフォルト値も設定）
    const selectedYear = window.initialData.selectedYear || 1900;
    const selectedMonth = window.initialData.selectedMonth || 1;
    const selectedDay = window.initialData.selectedDay || 1;

    // 年のオプションを生成（例: 1900年〜現在年）
    for (let year = 1900; year <= currentYear; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.text = year;
        yearSelect.add(option);
    }
    // Controllerから取得した値を設定
    yearSelect.value = selectedYear || 1900; // デフォルト値

    // 月のオプションを生成
    for (let month = 1; month <= 12; month++) {
        const option = document.createElement('option');
        option.value = month;
        option.text = month < 10 ? `0${month}` : month; // 2桁表示
        monthSelect.add(option);
    }
    // Controllerから取得した値を設定
    monthSelect.value = selectedMonth || 1; // デフォルト値

    // 日のオプションを生成
    function updateDays(year, month) {
        // 日のセレクトボックスをクリア
        daySelect.innerHTML = '';

        // 月ごとの日数を設定
        let daysInMonth;
        switch (month) {
            case 2: // 2月（うるう年に対応）
                daysInMonth = isLeapYear(year) ? 29 : 28;
                break;
            case 4: case 6: case 9: case 11: // 30日までの月
                daysInMonth = 30;
                break;
            default: // 31日までの月
                daysInMonth = 31;
        }

        // 日のオプションを生成
        for (let day = 1; day <= daysInMonth; day++) {
            const option = document.createElement('option');
            option.value = day;
            option.text = day < 10 ? `0${day}` : day; // 2桁表示
            daySelect.add(option);
        }
    }
    // うるう年の判定
    function isLeapYear(year) {
        return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    }

    // 月が変更されたときに日のオプションを更新
    monthSelect.addEventListener('change', function() {
        updateDays(parseInt(yearSelect.value), parseInt(monthSelect.value));
    });

    // 年が変更されたときに日のオプションを更新
    yearSelect.addEventListener('change', function() {
        updateDays(parseInt(yearSelect.value), parseInt(monthSelect.value));
    });

    // 初期ロード時にデフォルトの日数を設定
    updateDays(parseInt(yearSelect.value), parseInt(monthSelect.value));

    // Controllerから取得した値を設定
    daySelect.value = selectedDay || 1; // デフォルト値
}

document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("registrationForm");
    
    form.addEventListener("submit", function(event) {
        const postalCode1 = document.getElementById("postalCode1").value;
        const postalCode2 = document.getElementById("postalCode2").value;
        const postalCodeField = document.createElement("input");
        
        postalCodeField.setAttribute("type", "hidden");
        postalCodeField.setAttribute("name", "postalCode");
        postalCodeField.setAttribute("value", postalCode1 + "-" + postalCode2);
        
        form.appendChild(postalCodeField);
    });
});

document.addEventListener("DOMContentLoaded", function() {
    const postalCode1 = document.getElementById("postalCode1");
    const postalCode2 = document.getElementById("postalCode2");
    const addressField = document.getElementById("address");

    function fetchAddress(postalCode) {
        fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${postalCode}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200 && data.results) {
                    const result = data.results[0];
                    const address = `${result.address1} ${result.address2} ${result.address3}`;
                    addressField.value = address;
                } else {
                    addressField.value = '';
                }
            })
            .catch(error => {
                console.error('Error fetching address:', error);
                addressField.value = '';
            });
    }

    function handlePostalCodeChange() {
        const postalCode = `${postalCode1.value}-${postalCode2.value}`;
        if (postalCode.match(/^\d{3}-\d{4}$/)) {
            fetchAddress(postalCode.replace('-', ''));
        } else {
            addressField.value = '';
        }
    }

    postalCode1.addEventListener("input", handlePostalCodeChange);
    postalCode2.addEventListener("input", handlePostalCodeChange);
});

function encodeImageFileAsURL(element, hiddenFieldId) {
    const file = element.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = function () {
            document.getElementById(hiddenFieldId).value = reader.result;
        };
        reader.readAsDataURL(file);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('email-error');

    emailInput.addEventListener('blur', function() {
        const email = emailInput.value;
        if (email) {
            checkEmailExistence(email);
        }
    });

    function checkEmailExistence(email) {
        fetch(`/check-email?email=${encodeURIComponent(email)}`)
            .then(response => response.json())
            .then(data => {
                if (data) {
                    emailError.style.display = 'inline';
                } else {
                    emailError.style.display = 'none';
                }
            })
            .catch(error => {
                emailError.style.display = 'none'; // エラー時は表示しない
            });
    }
});