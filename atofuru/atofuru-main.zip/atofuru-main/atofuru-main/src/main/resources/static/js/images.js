document.addEventListener('DOMContentLoaded', function() {
    // LocalStorageの初期化
    localStorage.setItem('identityImageCount', 0);
    localStorage.setItem('identityImageCount2', 0);

    const myNumberCardBase64_1 = window.initialData.myNumberCardBase64_1 || '';
    const myNumberCardBase64_2 = window.initialData.myNumberCardBase64_2 || '';
    const idCardBase64_1 = window.initialData.idCardBase64_1 || '';
    const idCardBase64_2 = window.initialData.idCardBase64_2 || '';
    // セクションの初期化
    setupSection('identityImage', 'openFileDialog', 'openCamera', 'dropArea', 'fileList', 'identityImageCount', 'identityImage', 'myNumberCardBase64', myNumberCardBase64_1, myNumberCardBase64_2);
    setupSection('identityImage2', 'openFileDialog2', 'openCamera2', 'dropArea2', 'fileList2', 'identityImageCount2', 'identityImage2', 'idCardBase64', idCardBase64_1, idCardBase64_2);
});

function setupSection(fileInputId, openFileDialogId, openCameraId, dropAreaId, fileListId, counterId, sectionName, hiddenFieldId, base64Image_1, base64Image_2) {
    const fileInput = document.getElementById(fileInputId);
    const openFileDialogButton = document.getElementById(openFileDialogId);
    const openCameraButton = document.getElementById(openCameraId);
    const dropArea = document.getElementById(dropAreaId);
    const fileList = document.getElementById(fileListId);
    const hiddenField = document.getElementById(hiddenFieldId);
    const maxImages = 2;
    let imageCount = parseInt(localStorage.getItem(counterId)) || 0;
    let imageArray = JSON.parse(hiddenField.value || "[]"); // 既存のBase64データを読み込む

    if (base64Image_1) {
        imageArray.push('data:image/png;base64,' + base64Image_1); 
        imageCount++;
        if (base64Image_2) {  
            imageArray.push('data:image/png;base64,' + base64Image_2); 
            imageCount++;
        }
        hiddenField.value = JSON.stringify(imageArray);
    }

    // 初期表示
    imageArray.forEach((base64, index) => {
        displayImage(base64, `image_${index}.jpg`);
    });

    openCameraButton.addEventListener('click', () => {
        if (imageArray.length >= maxImages) {
            alert('画像は2つまでです。不要な画像を取り消してから操作してください。');
            return;
        }
        const cameraWindow = window.open('/register-camera', 'cameraWindow', 'width=800,height=600');
        window.name = sectionName; 
        cameraWindow.onload = function() {
            cameraWindow.postMessage({ type: sectionName }, '*');
        };
    });

    openFileDialogButton.addEventListener('click', () => {
        if (imageArray.length >= maxImages) {
            alert('画像は2つまでです。不要な画像を取り消してから操作してください。');
            return;
        }
        fileInput.value = '';
        fileInput.click();
    });

    fileInput.addEventListener('change', () => {
        handleFiles(); 
    });

    function handleFiles() {
        const files = Array.from(fileInput.files);
        if (files.length === 0) {
            console.log('No files selected.');
            return;
        }
    
        // 新しいファイルを処理
        files.forEach(file => {
            if (imageArray.length < maxImages) {
                const reader = new FileReader();
    
                reader.onload = function(event) {
                    displayImage(event.target.result, file.name);
                    imageArray.push(event.target.result); // 配列に追加
                    hiddenField.value = JSON.stringify(imageArray); // hiddenフィールドに保存
                };
    
                reader.readAsDataURL(file);
                imageCount++;
            }
        });
        fileInput.value = '';
    }
    
    dropArea.addEventListener('dragover', (event) => {
        event.preventDefault();
        event.stopPropagation();
        dropArea.classList.add('dragging');
    });

    dropArea.addEventListener('dragleave', () => {
        dropArea.classList.remove('dragging');
    });

    dropArea.addEventListener('drop', (event) => {
        event.preventDefault();
        event.stopPropagation();
        dropArea.classList.remove('dragging');

        if (imageArray.length >= maxImages) {
            alert('画像は2つまでです。不要な画像を取り消してから操作してください。');
            return;
        }
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const newFileList = new DataTransfer();
            for (let i = 0; i < fileInput.files.length; i++) {
                newFileList.items.add(fileInput.files[i]);
            }
            for (let i = 0; i < files.length; i++) {
                newFileList.items.add(files[i]);
            }
            fileInput.files = newFileList.files;
            handleFiles();
        }
    });

    function displayImage(imageSrc, fileName) {
        // 画像を取得し、Blob に変換
        fetch(imageSrc)
            .then(response => response.blob())
                // 新しく表示するファイル情報を作成
                const fileInfoDiv = document.createElement('div');
                fileInfoDiv.classList.add('file-info');
                fileInfoDiv.dataset.fileName = fileName;
    
                const img = document.createElement('img');
                img.src = imageSrc;
                img.alt = fileName;
                const fileNameSpan = document.createElement('span');
                fileNameSpan.textContent = truncateFileName(fileName, 15);
    
                const removeButton = document.createElement('button');
                removeButton.textContent = '取り消し';
                removeButton.addEventListener('click', () => {
                    removeFile(fileInfoDiv, imageSrc);
                });
    
                // UI に追加
                fileInfoDiv.appendChild(img);
                fileInfoDiv.appendChild(fileNameSpan);
                fileInfoDiv.appendChild(removeButton);
                fileList.appendChild(fileInfoDiv);
    }
    
    function removeFile(fileInfoDiv, imageSrc) {
        imageArray = imageArray.filter(src => src !== imageSrc); // 配列から削除
        hiddenField.value = JSON.stringify(imageArray); // hiddenフィールドに保存
        fileList.removeChild(fileInfoDiv);
        localStorage.setItem(counterId, imageArray.length); // カウントを更新
    }

    window.addEventListener('message', (event) => {
        if (event.data.image) {
            if (event.data.type === sectionName) {
                const file = 'sample_';
                const fileName = file.concat(String(imageArray.length), '.jpg');
                displayImage(event.data.image, fileName);
                imageArray.push(event.data.image); // 配列に追加
                hiddenField.value = JSON.stringify(imageArray); // hiddenフィールドに保存
                localStorage.setItem(counterId, imageArray.length); // カウントを更新
            }
        }
    });
    
    function truncateFileName(fileName, maxLength) {
        const halfWidthMaxLength = maxLength; // 半角文字数として設定
        const fullWidthMaxLength = Math.ceil(maxLength / 2); // 半角文字数から全角文字数に変換
    
        let truncatedName = fileName;
        let lengthCount = 0;
        let charCount = 0;
    
        for (let i = 0; i < fileName.length; i++) {
            const char = fileName.charAt(i);
            const isFullWidth = char.codePointAt(0) > 0x7F; // 全角かどうかを判定
    
            if (isFullWidth) {
                lengthCount += 2; // 全角文字は2カウント
            } else {
                lengthCount += 1; // 半角文字は1カウント
            }
    
            charCount += 1;
    
            if (lengthCount > halfWidthMaxLength) {
                truncatedName = fileName.substring(0, charCount) + '...';
                break;
            }
        }
        return truncatedName;
    }
}
