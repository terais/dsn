document.addEventListener('DOMContentLoaded', function() {
    // hidden フィールドからデータを取得して表示する
    document.getElementById('confirmLastName').textContent = document.getElementById('hiddenLastName').value;
    document.getElementById('confirmFirstName').textContent = document.getElementById('hiddenFirstName').value;
    document.getElementById('confirmLastNameKana').textContent = document.getElementById('hiddenLastNameKana').value;
    document.getElementById('confirmFirstNameKana').textContent = document.getElementById('hiddenFirstNameKana').value;
    document.getElementById('confirmEmail').textContent = document.getElementById('hiddenEmail').value;
    document.getElementById('confirmBirthDate').textContent = `${document.getElementById('hiddenBirthYear').value}年 ${document.getElementById('hiddenBirthMonth').value}月 ${document.getElementById('hiddenBirthDay').value}日`;
    document.getElementById('confirmPostalCode').textContent = document.getElementById('hiddenPostalCode').value;
    document.getElementById('confirmAddress').textContent = document.getElementById('hiddenAddress').value;
    document.getElementById('confirmPhoneNumber').textContent = document.getElementById('hiddenPhoneNumber').value;
    document.getElementById('confirmJob').textContent = document.getElementById('hiddenJob').value;
    document.getElementById('confirmIncome').textContent = document.getElementById('hiddenIncome').value;
    document.getElementById('confirmGender').textContent = document.getElementById('hiddenGender').value;
});
