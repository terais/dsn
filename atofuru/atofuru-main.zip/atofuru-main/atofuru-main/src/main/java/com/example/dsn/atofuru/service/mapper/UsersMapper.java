package com.example.dsn.atofuru.service.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.UsersEntity;

@Mapper
public interface UsersMapper {

    UsersEntity findByEmail(String email);
    UsersEntity findByUserId(Integer userId); 
    UsersEntity findByLoginId(String loginId); 
    boolean checkEmailExists(String email);
    UsersEntity findByIdentifier(String identifier);

    void insert(UsersEntity user);
    void update(UsersEntity user);
    void delete(int userId);
}
