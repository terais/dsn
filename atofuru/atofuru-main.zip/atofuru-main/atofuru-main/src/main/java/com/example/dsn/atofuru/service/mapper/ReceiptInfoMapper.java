package com.example.dsn.atofuru.service.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.ReceiptInfoEntity;

@Mapper
public interface ReceiptInfoMapper {

    // loginId でレシート情報を取得
    List<ReceiptInfoEntity> getReceiptInfoByLoginId(String loginId);

    // loginId と receiptId を条件にしてレシート情報を取得
    ReceiptInfoEntity getReceiptInfoByLoginIdAndReceiptId(Map<String, Object> params);

    // 複数レコードのバルクインサート
    void bulkInsert(List<ReceiptInfoEntity> receiptInfoList);

    Integer insertReceiptInfo(ReceiptInfoEntity receiptInfo);
}