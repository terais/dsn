package com.example.dsn.atofuru.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.service.entity.PurchaseInfoEntity;
import com.example.dsn.atofuru.service.mapper.PurchaseInfoMapper;

@Service
public class PurchaseInfoService {

    @Autowired
    private PurchaseInfoMapper purchaseInfoMapper;

    /**
     * 指定された login_id の購入情報を取得します。
     *
     * @param loginId ユーザーの login_id
     * @return 購入情報のリスト
     */
    public List<PurchaseInfoEntity> getPurchaseInfoByLoginId(String loginId) {
        return purchaseInfoMapper.getPurchaseInfoByLoginId(loginId);
    }
    
    public List<PurchaseInfoEntity> getPurchaseInfoByLoginIdAndReceiptId(String loginId, Integer receiptId) {
        return purchaseInfoMapper.getPurchaseInfoByLoginIdAndReceiptId(loginId, receiptId);
    }

    /**
     * 複数の購入情報をバルクインサートします。
     *
     * @param purchaseInfoList インサートする購入情報のリスト
     */
    public void bulkInsert(List<PurchaseInfoEntity> purchaseInfoList) {
        purchaseInfoMapper.bulkInsert(purchaseInfoList);
    }
}
