package com.example.dsn.atofuru.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dsn.atofuru.controller.dto.UserDto;
import com.example.dsn.atofuru.service.CustomUserDetailsService;
import com.example.dsn.atofuru.service.MasterDataService;
import com.example.dsn.atofuru.service.UserBase64RelService;
import com.example.dsn.atofuru.service.entity.GenderMasterEntity;
import com.example.dsn.atofuru.service.entity.IncomeMasterEntity;
import com.example.dsn.atofuru.service.entity.JobMasterEntity;
import com.example.dsn.atofuru.service.entity.UserBase64RelEntity;
import com.example.dsn.atofuru.service.entity.UsersEntity;

@Controller
public class AtofuruMenuController {
    
    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private UserBase64RelService UserBase64RelService;

    @Autowired
    private MasterDataService masterDataService;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    

    @GetMapping("/atofuru-menu")
    public String showAtofuruMenu(@RequestParam("userId") String userId, Model model) {
        UsersEntity user =  userDetailsService.findByLoginIdOrEmail(userId);
        model.addAttribute("username", user.getLastName() + " " + user.getFirstName());
        model.addAttribute("userId", user.getLoginId());
        return "atofuru-menu";
    }

    @GetMapping("/receipt-upload")
    public String showReceiptUpload(@RequestParam("userId") String userId, Model model) {
        UsersEntity user =  userDetailsService.findByLoginIdOrEmail(userId);
        model.addAttribute("username", user.getLastName() + " " + user.getFirstName());
        model.addAttribute("userId", user.getLoginId());
        model.addAttribute("loginId", user.getLoginId());
        return "receipt-upload";
    }

    @GetMapping("/user-info")
    public String showInfoUser(@RequestParam("userId") String userId, Model model) {
        // userId を使ってユーザー情報を取得する
        UsersEntity userEntity =  userDetailsService.findByLoginIdOrEmail(userId);
        UserDto user = new UserDto(userEntity);

        setUserUpdate(user.getLoginId(), user, model);

        GenderMasterEntity gender = masterDataService.getGenderByCode(user.getGender());
        JobMasterEntity job = masterDataService.getJobByCode(user.getJob());
        IncomeMasterEntity income = masterDataService.getIncomeByCode(user.getIncome());

        model.addAttribute("postalCode", user.getPostalCode());

        model.addAttribute("birthYear", user.getBirthYear());
        model.addAttribute("birthMonth", user.getBirthMonth());
        model.addAttribute("birthDay", user.getBirthDay());

        model.addAttribute("gender", gender.getGender());
        model.addAttribute("job", job.getJobName());
        model.addAttribute("income", income.getIncomeRange());

        return "user-info";
    }

    @PostMapping("/user-update")
    public String showInfoUpdate(@ModelAttribute UserDto user, Model model) {

        List<JobMasterEntity> jobs = masterDataService.getAllJobs();
        List<IncomeMasterEntity> incomes = masterDataService.getAllIncomes();
        List<GenderMasterEntity> genders = masterDataService.getAllGenders();

        model.addAttribute("jobs", jobs);
        model.addAttribute("incomes", incomes);
        model.addAttribute("genders", genders);

        setUserUpdate(user.getLoginId(), user, model);
        
        model.addAttribute("selectedYear", user.getBirthYear());
        model.addAttribute("selectedMonth", Integer.parseInt(user.getBirthMonth()));
        model.addAttribute("selectedDay", Integer.parseInt(user.getBirthDay()));

        model.addAttribute("postalCode1", user.getPostalCode().split("-")[0]);
        model.addAttribute("postalCode2", user.getPostalCode().split("-")[1]);

        model.addAttribute("genderName", user.getGender());
        model.addAttribute("jobName", user.getJob());
        model.addAttribute("incomeRange", user.getIncome());

        return "user-update";
    }

    private void setUserUpdate(String id, UserDto user, Model model) {
        
        UserBase64RelEntity rel = UserBase64RelService.selectUserBase64Rel(id);
        List<String> myNumberCardBase64List = new ArrayList<>();
        myNumberCardBase64List.add(rel.getMyNumberCardBase64_1());
        if(rel.getMyNumberCardBase64_2() != null) myNumberCardBase64List.add(rel.getMyNumberCardBase64_2());
        List<String> idCardBase64List = new ArrayList<>();
        idCardBase64List.add(rel.getIdCardBase64_1());
        if(rel.getIdCardBase64_2() != null) idCardBase64List.add(rel.getIdCardBase64_2());

        model.addAttribute("loginId", user.getLoginId());
        model.addAttribute("userId", user.getLoginId());

        model.addAttribute("lastName", user.getLastName());
        model.addAttribute("firstName", user.getFirstName());
        model.addAttribute("lastNameKana", user.getLastNameKana());
        model.addAttribute("firstNameKana", user.getFirstNameKana());
        model.addAttribute("email", user.getEmail());
        model.addAttribute("emailConfirm", user.getEmail());
        model.addAttribute("password", passwordEncoder.encode(user.getPassword()));
        model.addAttribute("passwordConfirm", passwordEncoder.encode(user.getPassword()));
        model.addAttribute("address", user.getAddress());
        model.addAttribute("phoneNumber", user.getPhoneNumber());

        model.addAttribute("myNumberCardBase64", myNumberCardBase64List);
        model.addAttribute("idCardBase64", idCardBase64List);

        model.addAttribute("myNumberCardBase64_1", myNumberCardBase64List.get(0));
        if (myNumberCardBase64List.size() > 1) model.addAttribute("myNumberCardBase64_2", myNumberCardBase64List.get(1));
        model.addAttribute("idCardBase64_1", idCardBase64List.get(0));
        if (idCardBase64List.size() > 1) model.addAttribute("idCardBase64_2", idCardBase64List.get(1));
    }
}
