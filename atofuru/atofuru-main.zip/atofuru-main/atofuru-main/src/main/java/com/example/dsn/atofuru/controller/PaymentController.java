package com.example.dsn.atofuru.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.dsn.atofuru.controller.dto.ReceiptDto;
import com.example.dsn.atofuru.service.PurchaseInfoService;
import com.example.dsn.atofuru.service.ReceiptInfoService;
import com.example.dsn.atofuru.service.entity.PurchaseInfoEntity;
import com.example.dsn.atofuru.service.entity.ReceiptInfoEntity;

@Controller
public class PaymentController {

    @PostMapping("/payment")
    public String showPayment(@ModelAttribute ReceiptDto receiptDto, Model model) {
        
        model.addAttribute("loginId", receiptDto.getLoginId());
        // receiptDtoの内容を確認する
        System.out.println(receiptDto.getLoginId());
        System.out.println(receiptDto.getStoreName());
        System.out.println(receiptDto.getStoreAddress());
        System.out.println(receiptDto.getStorePhone());
        System.out.println(receiptDto.getDate());
        System.out.println(receiptDto.getTotalAmount());
        System.out.println(receiptDto.getDatas());

        /* TODO 本来ならここではないがMockのよりこの先が無いためここで登録 */
        registerReceipt(receiptDto);

        return "payment";
    }

    @Autowired
    private ReceiptInfoService receiptInfoService;
    
    @Autowired
    private PurchaseInfoService purchaseInfoService;
    
    private void registerReceipt(ReceiptDto receiptDto) {
        ReceiptInfoEntity receiptEntity = new ReceiptInfoEntity(true);
        receiptEntity.setLoginId(receiptDto.getLoginId());
        receiptEntity.setPurchaseStore(receiptDto.getStoreName());
        receiptEntity.setPurchaseAddress(receiptDto.getStoreAddress());
        receiptEntity.setPurchasePhone(receiptDto.getStorePhone());

        String base64Image = receiptDto.getReceiptBase64().replaceAll("data:image/png;base64,", "")
            .replaceAll("data:image/jpeg;base64,", "")
            .replaceAll("data:image/jpg;base64,", "");
        base64Image = base64Image.replaceAll("\\[", "");
        base64Image = base64Image.replaceAll("\\]", "");
        base64Image = base64Image.replaceAll("\"", "");
        receiptEntity.setReceiptBase64(base64Image);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d HH:mm");

        String cleanedDateTimeStr = receiptDto.getDate().replaceAll("\\(.*\\)", "").trim();
        // 文字列を LocalDateTime に変換
        LocalDateTime localDateTime = LocalDateTime.parse(cleanedDateTimeStr, formatter);

        receiptEntity.setPurchaseDate(localDateTime);
        receiptEntity.setTotalAmount(Integer.parseInt(receiptDto.getTotalAmount().replaceAll("[^\\d]", "")));
        Integer receiptId = receiptInfoService.insertReceiptInfo(receiptEntity);
        Set<Entry<String, String>> entrySet = receiptDto.getDatas().entrySet();
        List<PurchaseInfoEntity> purchaseInfoList = new ArrayList<>();
        for (Entry<String, String> entry : entrySet) {
            PurchaseInfoEntity entity = new PurchaseInfoEntity(true);
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
            entity.setReceiptId(receiptId);
            entity.setLoginId(receiptDto.getLoginId());
            
            entity.setCommodity(entry.getKey());
            entity.setPurchaseAmount(Integer.parseInt(entry.getValue().replaceAll("[^\\d]", "")));
            purchaseInfoList.add(entity);
        }
        purchaseInfoService.bulkInsert(purchaseInfoList);
    }
}
