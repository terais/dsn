package com.example.dsn.atofuru.controller.debug;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/debug")
public class DebugController {

    @GetMapping("/session")
    public String getSessionAttributes(HttpSession session) {
        Object securityContext = session.getAttribute("SPRING_SECURITY_CONTEXT");
        return "Security Context: " + (securityContext != null ? securityContext.toString() : "null");
    }

    @GetMapping("/cookies")
    public String getCookies(@RequestHeader HttpHeaders headers) {
        List<String> cookies = headers.get(HttpHeaders.COOKIE);
        return "Cookies: " + (cookies != null ? cookies.toString() : "No Cookies");
    }
}