package com.example.dsn.atofuru.controller.dto;

import java.time.LocalDate;

import com.example.dsn.atofuru.service.entity.UsersEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    public UserDto(UsersEntity entity) {
        this.loginId = entity.getLoginId();
        this.lastName = entity.getLastName();
        this.firstName = entity.getFirstName();
        this.lastNameKana = entity.getLastNameKana();
        this.firstNameKana = entity.getFirstNameKana();
        this.email = entity.getEmail();
        this.password = entity.getPassword();
        this.gender = entity.getGenderCode();
        this.birthYear = String.valueOf(LocalDate.now().getYear());
        this.birthMonth = String.format("%02d", LocalDate.now().getMonthValue());
        this.birthDay = String.format("%02d", LocalDate.now().getDayOfMonth());
        this.postalCode = entity.getPostalCode();
        this.address = entity.getAddress();
        this.phoneNumber = entity.getPhoneNumber();
        this.job = entity.getJobCode();
        this.income = entity.getIncomeCode();
    }

    private String loginId;
    private String lastName;
    private String firstName;
    private String lastNameKana;
    private String firstNameKana;
    private String email;
    private String emailConfirm;
    private String password;
    private String passwordConfirm;
    private String gender;
    private String birthYear;
    private String birthMonth;
    private String birthDay;
    private String postalCode;
    private String address;
    private String phoneNumber;
    private String job;
    private String income;
    private String myNumberCardBase64;
    private String idCardBase64;

    private String receiptBase64;
}