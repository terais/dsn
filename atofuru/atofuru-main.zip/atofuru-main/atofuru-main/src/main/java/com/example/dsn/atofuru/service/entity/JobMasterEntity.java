package com.example.dsn.atofuru.service.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobMasterEntity {
    private String jobCode;
    private String jobName;
    private String validFrom;
    private String validTo;
    private String createdBy;
    private String createdAt;
    private String updatedBy;
    private String updatedAt;
}