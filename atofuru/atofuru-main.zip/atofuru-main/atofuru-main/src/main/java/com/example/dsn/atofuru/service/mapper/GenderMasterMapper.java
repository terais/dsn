package com.example.dsn.atofuru.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.GenderMasterEntity;

@Mapper
public interface GenderMasterMapper {
    
    List<GenderMasterEntity> getAllGenders();
    GenderMasterEntity getGenderByCode(String key);
    GenderMasterEntity getGenderByName(String key);
    GenderMasterEntity findByIdentifier(String identifier);
}
