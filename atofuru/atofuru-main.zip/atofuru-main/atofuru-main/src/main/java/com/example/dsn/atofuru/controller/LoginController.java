package com.example.dsn.atofuru.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.dsn.atofuru.service.CustomUserDetailsService;
import com.example.dsn.atofuru.service.entity.UsersEntity;

@Controller
public class LoginController {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }
    
    @PostMapping("/success")
    public String success(Authentication authentication, Model model) {
        Object principal = authentication.getPrincipal();
        String username = "";
        if (principal instanceof User) {
            User user = (User) principal;
            username = user.getUsername();
        } else {
            throw new IllegalArgumentException("Principal is not of type User");
        }
        UsersEntity user =  userDetailsService.findByUserId(Integer.parseInt(username));
        model.addAttribute("username", user.getLastName() + " " + user.getFirstName());
        model.addAttribute("userId", user.getLoginId());
        return "atofuru-menu";
    }
}
