package com.example.dsn.atofuru.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.JobMasterEntity;

@Mapper
public interface JobMasterMapper {
    
    List<JobMasterEntity> getAllJobs();
    JobMasterEntity getJobByCode(String key);
    JobMasterEntity getJobByName(String key);
    JobMasterEntity findByIdentifier(String identifier);
}