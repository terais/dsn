package com.example.dsn.atofuru.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.dsn.atofuru.controller.dto.ReceiptDto;
// import com.example.dsn.atofuru.controller.dto.ReceiptDto;
import com.example.dsn.atofuru.controller.dto.UserDto;
import com.example.dsn.atofuru.service.CustomUserDetailsService;
import com.example.dsn.atofuru.service.OcrAnalyzeService;
import com.example.dsn.atofuru.service.entity.UsersEntity;

@Controller
@RequestMapping("/receipt")
public class ReceiptController {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private OcrAnalyzeService ocrAnalyzeService;

    @PostMapping("/upload")
    public String receiptUpload(@ModelAttribute UserDto user, Model model) {
        List<String> ocrList = ocrAnalyzeService.getOcr(user.getReceiptBase64());
        ReceiptDto receiptDto = ocrAnalyzeService.ocrAnalyze(ocrList, user.getLoginId());

        UsersEntity usersEntity = userDetailsService.findByLoginIdOrEmail(user.getLoginId());

        Map<String, String> commodityMap = new HashMap<>();

        commodityMap.put("大きいウインナー", "¥158");
        commodityMap.put("直巻 しゃけ", "¥150");
        commodityMap.put("直巻 明太子マヨネーズ", "¥150");
        commodityMap.put("Fボスオリジナル", "¥110");
        commodityMap.put("綴じノートA6B", "¥178");
        commodityMap.put("サラサクリップ", "¥100");
        commodityMap.put("スパイシーチキン", "¥198");
        commodityMap.put("フィリップモリス14", "¥860");
        commodityMap.put("レジ袋12号バイオマス", "¥3");

        model.addAttribute("userName", usersEntity.getLastName() + " " + usersEntity.getFirstName());
        model.addAttribute("loginId", usersEntity.getLoginId());

        // Model にデータを追加
        model.addAttribute("datas", commodityMap);
        model.addAttribute("yyyymmdd", receiptDto.getDate());
        model.addAttribute("storeName", receiptDto.getStoreName());
        model.addAttribute("storeAddress", receiptDto.getStoreAddress());
        model.addAttribute("storePhone", receiptDto.getStorePhone());
        model.addAttribute("yyyymmddhhss", receiptDto.getDate());
        model.addAttribute("totalAmount", receiptDto.getTotalAmount());
        model.addAttribute("calcAmount", receiptDto.getCalcAmount());
        model.addAttribute("receiptBase64", user.getReceiptBase64());

        return "receipt-info";
    }
}
