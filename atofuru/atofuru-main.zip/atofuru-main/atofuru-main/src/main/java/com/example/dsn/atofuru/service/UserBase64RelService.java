package com.example.dsn.atofuru.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.service.entity.UserBase64RelEntity;
import com.example.dsn.atofuru.service.mapper.UserBase64RelMapper;

@Service
public class UserBase64RelService {

    @Autowired
    private UserBase64RelMapper userBase64RelMapper;

    @Autowired
    private UtilService utilService;

    public void insertUserBase64Rel(String userId, String myNumberCardBase64, String idCardBase64) {
        UserBase64RelEntity userBase64RelEntity = toEntity(userId, myNumberCardBase64, idCardBase64, true);
        userBase64RelMapper.insertUserBase64Rel(userBase64RelEntity);
    }
    public void updateUserBase64Rel(String userId, String myNumberCardBase64, String idCardBase64) {
        UserBase64RelEntity userBase64RelEntity = toEntity(userId, myNumberCardBase64, idCardBase64, false);
        userBase64RelMapper.updateUserBase64Rel(userBase64RelEntity);
    }
    public UserBase64RelEntity selectUserBase64Rel(String userId) {
        UserBase64RelEntity userBase64RelEntity = userBase64RelMapper.selectUserBase64Rel(userId);
        return userBase64RelEntity;
    }

    private UserBase64RelEntity toEntity(String userId, String myNumberCardBase64, String idCardBase64, Boolean isCreate) {
        List<String> myNumberCardBase64List = utilService.parseBase64Array(myNumberCardBase64);
        List<String> idCardBase64List = utilService.parseBase64Array(idCardBase64);
        
        UserBase64RelEntity userBase64RelEntity = new UserBase64RelEntity(isCreate);
        userBase64RelEntity.setUserId(userId);
        userBase64RelEntity.setMyNumberCardBase64_1(myNumberCardBase64List.get(0));
        if(myNumberCardBase64List.size() > 1) {
            userBase64RelEntity.setMyNumberCardBase64_2(myNumberCardBase64List.get(1));
        }
        userBase64RelEntity.setIdCardBase64_1(idCardBase64List.get(0));

        if(idCardBase64List.size() > 1) {
            userBase64RelEntity.setIdCardBase64_2(idCardBase64List.get(1));
        }
        return userBase64RelEntity;
    }
}
