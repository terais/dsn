package com.example.dsn.atofuru.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.service.mapper.UtilMasterMapper;

@Service
public class UtilService {

    @Autowired
    private UtilMasterMapper utilMasterMapper;

    public String getStringDate() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日(E) HH時mm分ss秒");
        String formattedDateTime = now.format(formatter);
        return formattedDateTime;
    }

    public boolean isBase64(String base64String) {
        try {
            // Base64 デコードを試みる
            Base64.getDecoder().decode(base64String);
            return true;
        } catch (IllegalArgumentException e) {
            // デコードに失敗した場合
            return false;
        }
    }
    public String getProjectUrl() {
        return utilMasterMapper.selectByKey("system", "project.url").getValue();
    }

    public List<String> parseBase64Array(String base64String) {
        base64String = base64String.replaceAll("data:image/png;base64,", "")
            .replaceAll("data:image/jpeg;base64,", "")
            .replaceAll("data:image/jpg;base64,", "");
        base64String = base64String.replaceAll("\\[", "");
        base64String = base64String.replaceAll("\\]", "");
        base64String = base64String.replaceAll("\"", "");
        if (base64String == null || base64String.isEmpty()) {
            return Collections.emptyList();
        }
    
        // 文字列がカンマで区切られていると仮定
        return Arrays.asList(base64String.split(","));
    }
}
