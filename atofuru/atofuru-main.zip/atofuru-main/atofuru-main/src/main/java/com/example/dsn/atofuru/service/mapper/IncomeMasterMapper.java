package com.example.dsn.atofuru.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.IncomeMasterEntity;

@Mapper
public interface IncomeMasterMapper {
    
    List<IncomeMasterEntity> getAllIncomes();
    IncomeMasterEntity getIncomeByCode(String key);
    IncomeMasterEntity getIncomeByName(String key);
    IncomeMasterEntity findByIdentifier(String identifier);
}
