package com.example.dsn.atofuru.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.dsn.atofuru.service.entity.PurchaseInfoEntity;

@Mapper
public interface PurchaseInfoMapper {

    List<PurchaseInfoEntity> getPurchaseInfoByLoginId(@Param("loginId") String loginId);

    List<PurchaseInfoEntity> getPurchaseInfoByLoginIdAndReceiptId(@Param("loginId") String loginId, @Param("receiptId") Integer receiptId);

    void bulkInsert(@Param("purchaseInfoList") List<PurchaseInfoEntity> purchaseInfoList);
}
