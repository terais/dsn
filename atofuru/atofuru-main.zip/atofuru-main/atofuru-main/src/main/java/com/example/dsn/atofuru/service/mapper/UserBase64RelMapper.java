package com.example.dsn.atofuru.service.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.UserBase64RelEntity;

@Mapper
public interface UserBase64RelMapper {

    void insertUserBase64Rel(UserBase64RelEntity userBase64RelEntity);
    UserBase64RelEntity selectUserBase64Rel(String userId);
    void updateUserBase64Rel(UserBase64RelEntity userBase64RelEntity);
    void deleteUserBase64Rel(Long userId);
}