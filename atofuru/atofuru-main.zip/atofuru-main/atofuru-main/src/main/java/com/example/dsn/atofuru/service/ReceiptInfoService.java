package com.example.dsn.atofuru.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.service.entity.ReceiptInfoEntity;
import com.example.dsn.atofuru.service.mapper.ReceiptInfoMapper;

@Service
public class ReceiptInfoService {

    @Autowired
    private ReceiptInfoMapper receiptInfoMapper;

    /**
     * loginId でレシート情報を取得
     * 
     * @param loginId ユーザーのログインID
     * @return レシート情報のエンティティ
     */
    public List<ReceiptInfoEntity> getReceiptInfoByLoginId(String loginId) {
        return receiptInfoMapper.getReceiptInfoByLoginId(loginId);
    }

    /**
     * loginId と receiptId を条件にしてレシート情報を取得
     * 
     * @param loginId ユーザーのログインID
     * @param receiptId レシートID
     * @return レシート情報のエンティティ
     */
    public ReceiptInfoEntity getReceiptInfoByLoginIdAndReceiptId(String loginId, Integer receiptId) {
        Map<String, Object> params = new HashMap<>();
        params.put("loginId", loginId);
        params.put("receiptId", receiptId);
        return receiptInfoMapper.getReceiptInfoByLoginIdAndReceiptId(params);
    }

    /**
     * 複数レコードのバルクインサート
     * 
     * @param receiptInfoList レシート情報のリスト
     */
    public void bulkInsert(List<ReceiptInfoEntity> receiptInfoList) {
        receiptInfoMapper.bulkInsert(receiptInfoList);
    }

    public Integer insertReceiptInfo(ReceiptInfoEntity receiptInfoEntity) {
        return receiptInfoMapper.insertReceiptInfo(receiptInfoEntity);
    }
}

