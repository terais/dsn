package com.example.dsn.atofuru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtofuruApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtofuruApplication.class, args);
	}
}
