package com.example.dsn.atofuru.service.entity;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsersEntity {

    private String userId;
    private String loginId;
    private String lastName;
    private String firstName;
    private String lastNameKana;
    private String firstNameKana;
    private String email;
    private String password;
    private LocalDate birthDate;
    private String postalCode;
    private String address;
    private String phoneNumber;
    private String jobCode;
    private String incomeCode;
    private String genderCode;
    private LocalDate validFrom;
    private LocalDate validTo;
    private String createdBy;
    private Timestamp createdAt;
    private String updatedBy;
    private Timestamp updatedAt;

    public UsersEntity(Boolean isCreate) {
        this.validFrom = LocalDate.now(); // 現在日付
        this.validTo = LocalDate.of(9999, 12, 31); // 9999-12-31に設定

        String hostname = getHostname(); // ホスト名の取得
        
        if (isCreate) {
            this.createdBy = hostname; // ホスト名を作成者に設定
            this.createdAt = Timestamp.valueOf(LocalDateTime.now()); // 現在の日時を設定
        } else {
            this.updatedBy = hostname; // ホスト名を更新者に設定
            this.updatedAt = Timestamp.valueOf(LocalDateTime.now()); // 現在の日時を設定
        }
    }

    // ホスト名を取得するメソッド
    private String getHostname() {
        try {
            return InetAddress.getLocalHost().getHostName(); // システムのホスト名を取得
        } catch (UnknownHostException e) {
            e.printStackTrace();
            return "unknown"; // 取得に失敗した場合のフォールバック
        }
    }
}
