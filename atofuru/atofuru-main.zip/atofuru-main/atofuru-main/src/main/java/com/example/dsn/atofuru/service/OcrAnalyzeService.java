package com.example.dsn.atofuru.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.controller.dto.ReceiptDto;
import com.google.cloud.vision.v1.AnnotateImageRequest;
import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.google.cloud.vision.v1.Feature;
import com.google.cloud.vision.v1.Image;
import com.google.cloud.vision.v1.ImageAnnotatorClient;
import com.google.cloud.vision.v1.TextAnnotation;
import com.google.protobuf.ByteString;

@Service
public class OcrAnalyzeService {

    public List<String> getOcr(String base64Image) {
        try (ImageAnnotatorClient visionClient = ImageAnnotatorClient.create()) {
            base64Image = base64Image.replaceAll("data:image/png;base64,", "")
                .replaceAll("data:image/jpeg;base64,", "")
                .replaceAll("data:image/jpg;base64,", "");
            base64Image = base64Image.replaceAll("\\[", "");
            base64Image = base64Image.replaceAll("\\]", "");
            base64Image = base64Image.replaceAll("\"", "");
            ByteString imgBytes = ByteString.copyFrom(Base64.getDecoder().decode(base64Image));
            Image img = Image.newBuilder().setContent(imgBytes).build();

            // Create a request with the image and features
            AnnotateImageRequest request = AnnotateImageRequest.newBuilder()
                    .addFeatures(Feature.newBuilder().setType(Feature.Type.TEXT_DETECTION))
                    .setImage(img)
                    .build();
            // Perform text detection on the image
            AnnotateImageResponse response = visionClient.batchAnnotateImages(Collections.singletonList(request)).getResponses(0);
            TextAnnotation annotation = response.getFullTextAnnotation();
            
            // ocrAnalyze_ai(annotation.getText());

            return ocrSetList(annotation.getText());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private List<String> ocrSetList(String data) {
        String[] lines = data.split("\\r?\\n");

        // List に変換
        List<String> lineList = new ArrayList<>();
        for (String line : lines) {
            // System.out.println(line);
            lineList.add(line);
        }
        return lineList;
    }

    /* TODO 肝となるロジック */
    public ReceiptDto ocrAnalyze(List<String> datas, String loginId) {
        ReceiptDto receiptDto = new ReceiptDto();
        receiptDto.setLoginId(loginId);
        String storeName = "";
        String storeAddress = "";
        String storePhone = "";
        String date = "";
        List<String> totalStringList = new ArrayList<>();
        List<String> totalMountList = new ArrayList<>();
        // commodity
        Map<String, String> totalMap = new HashMap<>();
        Map<String, String> commodityMap = new HashMap<>();
        String commodity = "";
        int totalIndex = 0;
        /* TODO このロジックは無茶 */
        for (int i = 0; i < datas.size(); i++) {
            if (i <= 1) {
                // 店名はほぼ1行目
                storeName += datas.get(i) + " ";
            } else if (i > 1 && i <= 3) {
                // 住所はマスタかWEB APIで含んでいるかで判定
                storeAddress += datas.get(i);
            } else if (i == 4) {
                // 電話番号は正規表現でフォーマットにマッチするかで判定
                storePhone = datas.get(i);
            } else if (i == 6) {
                // 日付はは正規表現でフォーマットにマッチするかで判定
                date = datas.get(i);
            } else if (datas.get(i).contains("合計")) {
                // 合計の文字列で行けるか、値引き合計とかうざい、商品合計のパターンもある、
                totalStringList.add(datas.get(i));
                totalIndex = i;
            } else if (i == (totalIndex + 1)) {
                totalMountList.add(datas.get(i));
            } else if (i >= 9) {
                // 商品
                if (i % 2 == 0) {
                    commodityMap.put(commodity, datas.get(i));
                } else {
                    commodity = datas.get(i);
                }
            }
        }

        for (int i = 0; i < totalStringList.size(); i++) {
            totalMap.put(totalStringList.get(i), totalMountList.get(i));
        }

        String regex = "(\\d{4})年\\s*(\\d{1,2})月\\s*(\\d{1,2})日\\s*\\(([^)]+)\\)";
        String replacement = "$1/$2/$3($4)";
        date = date.replaceAll(regex, replacement);
        receiptDto.setDate(date);
        receiptDto.setStoreName(storeName);
        receiptDto.setStoreAddress(storeAddress);
        storePhone = storePhone.replaceAll("[^0-9０１２３４５６７８９\\-ー]", "");
        receiptDto.setStorePhone(storePhone);
        receiptDto.setTotalAmount(totalMap.get("合計"));
        receiptDto.setCalcAmount(getCalcAmount());

        return receiptDto;
    }
    

    // /* TODO 課金が必要 */
    // public void ocrAnalyze_ai(String ocrText) {
    //     try {
    //         // HTTPクライアントの作成
    //         CloseableHttpClient httpClient = HttpClients.createDefault();
    //         HttpPost httpPost = new HttpPost("https://api.openai.com/v1/chat/completions");

    //         // リクエストヘッダーの設定
    //         httpPost.setHeader("Authorization", "Bearer " + "{API_KEY}");
    //         httpPost.setHeader("Content-Type", "application/json");

    //         JSONObject requestBody = new JSONObject();
    //         requestBody.put("model", "gpt-3.5-turbo");
    //         JSONArray messages = new JSONArray();
    //         JSONObject userMessage = new JSONObject();
    //         userMessage.put("role", "user");
    //         userMessage.put("content", "以下のOCR結果から必要な情報を抽出してください:\n" + ocrText);
    //         messages.put(userMessage);
    //         requestBody.put("messages", messages);
    //         StringEntity entity = new StringEntity(requestBody.toString());
    //         httpPost.setEntity(entity);

    //         CloseableHttpResponse response = httpClient.execute(httpPost);
    //         BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
    //         StringBuilder responseString = new StringBuilder();
    //         String line;
    //         while ((line = reader.readLine()) != null) {
    //             responseString.append(line);
    //         }
    //         reader.close();
    //         response.close();

    //         // レスポンスの内容を表示
    //         // String jsonResponseString = responseString.toString();
    //         // System.out.println("APIレスポンス: " + jsonResponseString);

    //         // // レスポンスの解析
    //         // JSONObject jsonResponse = new JSONObject(jsonResponseString);
    //         // JSONArray choices = jsonResponse.getJSONArray("choices");
    //         // JSONObject choice = choices.getJSONObject(0);
    //         // String content = choice.getJSONObject("message").getString("content");

    //         // System.out.println("解析結果:\n" + content);

    //     } catch (Exception e) {
    //         e.printStackTrace();
    //     }
    // }

    private String getCalcAmount(/* TODO 合計金額 */) {
        return "{計算した金額が出ます}";
    }
}
