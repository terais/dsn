package com.example.dsn.atofuru.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.service.entity.GenderMasterEntity;
import com.example.dsn.atofuru.service.entity.IncomeMasterEntity;
import com.example.dsn.atofuru.service.entity.JobMasterEntity;
import com.example.dsn.atofuru.service.mapper.GenderMasterMapper;
import com.example.dsn.atofuru.service.mapper.IncomeMasterMapper;
import com.example.dsn.atofuru.service.mapper.JobMasterMapper;

@Service
public class MasterDataService {

    @Autowired
    private JobMasterMapper jobMapper;

    @Autowired
    private IncomeMasterMapper incomeMapper;

    @Autowired
    private GenderMasterMapper genderMapper;

    public List<JobMasterEntity> getAllJobs() {
        return jobMapper.getAllJobs();
    }

    public List<IncomeMasterEntity> getAllIncomes() {
        return incomeMapper.getAllIncomes();
    }

    public List<GenderMasterEntity> getAllGenders() {
        return genderMapper.getAllGenders();
    }

    public JobMasterEntity getJobByCode(String key) {
        return jobMapper.getJobByCode(key);
    }

    public IncomeMasterEntity getIncomeByCode(String key) {
        return incomeMapper.getIncomeByCode(key);
    }

    public GenderMasterEntity getGenderByCode(String key) {
        return genderMapper.getGenderByCode(key);
    }

    public JobMasterEntity getJobByName(String key) {
        return jobMapper.getJobByName(key);
    }

    public IncomeMasterEntity getIncomeByName(String key) {
        return incomeMapper.getIncomeByName(key);
    }

    public GenderMasterEntity getGenderByName(String key) {
        return genderMapper.getGenderByName(key);
    }

    public JobMasterEntity findByIdentifierJob(String key) {
        return jobMapper.findByIdentifier(key);
    }

    public IncomeMasterEntity findByIdentifierIncome(String key) {
        return incomeMapper.findByIdentifier(key);
    }

    public GenderMasterEntity findByIdentifierGender(String key) {
        return genderMapper.findByIdentifier(key);
    }
}
