package com.example.dsn.atofuru.service.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UtilMasterEntity {
    private String systemKey1;
    private String systemKey2;
    private String value;
    private LocalDate validFrom;
    private LocalDate validTo;
    private String createdBy;
    private LocalDateTime createdAt;
    private String updatedBy;
    private LocalDateTime updatedAt;
}
