package com.example.dsn.atofuru.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dsn.atofuru.service.CustomUserDetailsService;
import com.example.dsn.atofuru.service.PurchaseInfoService;
import com.example.dsn.atofuru.service.ReceiptInfoService;
import com.example.dsn.atofuru.service.entity.PurchaseInfoEntity;
import com.example.dsn.atofuru.service.entity.ReceiptInfoEntity;
import com.example.dsn.atofuru.service.entity.UsersEntity;

@Controller
public class InfoHistoryControler {
    
    @Autowired
    private PurchaseInfoService purchaseInfoService;

    @Autowired
    private ReceiptInfoService receiptInfoService;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @GetMapping("/info-history")
    public String showInfoHistory(@RequestParam("userId") String userId, Model model) {
        // ユーザー情報の取得
        UsersEntity user = userDetailsService.findByLoginIdOrEmail(userId);
        model.addAttribute("username", user.getLastName() + " " + user.getFirstName());
        model.addAttribute("loginId", user.getLoginId());

        // 購入履歴の取得
        List<ReceiptInfoEntity> receiptList = receiptInfoService.getReceiptInfoByLoginId(user.getLoginId());
        // LocalDateTime を yyyy/MM/dd(曜日) 形式にフォーマット
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd(EEE)", Locale.JAPAN);
        for (ReceiptInfoEntity receipt : receiptList) {
            String formattedPurchaseDate = receipt.getPurchaseDate().format(formatter);
            receipt.setFormattedPurchaseDate(formattedPurchaseDate);
            receipt.setPaymentAmount(0);
        }
        
        Integer totalPaymentAmount = receiptList.stream().mapToInt(ReceiptInfoEntity::getPaymentAmount).sum();
        model.addAttribute("totalAmount", totalPaymentAmount);
        model.addAttribute("receiptList", receiptList);
        LocalDate currentDate = LocalDate.now();
        String formattedDate = currentDate.format(formatter);
        model.addAttribute("nowDate", formattedDate);

        return "info-history";
    }

    @GetMapping("/info-history-details")
    public String showInfoHistoryDetails(@RequestParam("loginId") String loginId, @RequestParam("receiptId") Integer receiptId, Model model) {
        // 購入詳細情報の取得
        List<PurchaseInfoEntity> purchaseInfoList = purchaseInfoService.getPurchaseInfoByLoginIdAndReceiptId(loginId, receiptId);
        ReceiptInfoEntity receiptInfo = receiptInfoService.getReceiptInfoByLoginIdAndReceiptId(loginId, receiptId);
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd(EEE)", Locale.JAPAN);
        String formattedPurchaseDate = receiptInfo.getPurchaseDate().format(formatter);
        receiptInfo.setFormattedPurchaseDate(formattedPurchaseDate);
        
        receiptInfo.setPaymentAmount(0);
        model.addAttribute("receiptInfo", receiptInfo);
        model.addAttribute("purchaseInfoList", purchaseInfoList);

        return "info-history-details";
    }
}
