package com.example.dsn.atofuru.service.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncomeMasterEntity {
    private String incomeCode;
    private String incomeRange;
    private String validFrom;
    private String validTo;
    private String createdBy;
    private String createdAt;
    private String updatedBy;
    private String updatedAt;
}