package com.example.dsn.atofuru.controller.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ReceiptDto {
    
    private Integer receiptId;
    private String loginId;
    private String storeName;
    private String storeAddress;
    private String storePhone;
    private String date;
    private Map<String, String> datas;
    private String totalAmount;
    private String calcAmount;
    private String receiptBase64;

    public ReceiptDto() {
        datas = new HashMap<>();
    }
}
