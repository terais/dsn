package com.example.dsn.atofuru.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dsn.atofuru.controller.dto.UserDto;
import com.example.dsn.atofuru.service.CustomUserDetailsService;
import com.example.dsn.atofuru.service.EmailService;
import com.example.dsn.atofuru.service.MasterDataService;
import com.example.dsn.atofuru.service.UserBase64RelService;
import com.example.dsn.atofuru.service.UtilService;
import com.example.dsn.atofuru.service.entity.GenderMasterEntity;
import com.example.dsn.atofuru.service.entity.IncomeMasterEntity;
import com.example.dsn.atofuru.service.entity.JobMasterEntity;

@Controller
@RequestMapping("/register")
public class RegisterController {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private MasterDataService masterDataService;

    @Autowired
    private UserBase64RelService userBase64RelService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private EmailService emailService;

    @Autowired
    private UtilService utilService;

    @GetMapping
    public String showRegistrationForm(Model model) {

        List<JobMasterEntity> jobs = masterDataService.getAllJobs();
        List<IncomeMasterEntity> incomes = masterDataService.getAllIncomes();
        List<GenderMasterEntity> genders = masterDataService.getAllGenders();

        model.addAttribute("jobs", jobs);
        model.addAttribute("incomes", incomes);
        model.addAttribute("genders", genders);
    
        return "register"; 
    }
    
    @PostMapping("/confirm")
    public String confirmRegistration(@ModelAttribute UserDto user, Model model) {

        List<String> myNumberCardBase64List = utilService.parseBase64Array(user.getMyNumberCardBase64());
        List<String> idCardBase64List = utilService.parseBase64Array(user.getIdCardBase64());
        GenderMasterEntity gender = masterDataService.getGenderByCode(user.getGender());
        JobMasterEntity job = masterDataService.getJobByCode(user.getJob());
        IncomeMasterEntity income = masterDataService.getIncomeByCode(user.getIncome());

        model.addAttribute("lastName", user.getLastName());
        model.addAttribute("firstName", user.getFirstName());
        model.addAttribute("lastNameKana", user.getLastNameKana());
        model.addAttribute("firstNameKana", user.getFirstNameKana());
        model.addAttribute("email", user.getEmail());
        model.addAttribute("password", passwordEncoder.encode(user.getPassword()));
        model.addAttribute("gender", gender.getGender());
        model.addAttribute("birthYear", user.getBirthYear());
        model.addAttribute("birthMonth", user.getBirthMonth());
        model.addAttribute("birthDay", user.getBirthDay());
        model.addAttribute("postalCode", user.getPostalCode());
        model.addAttribute("address", user.getAddress());
        model.addAttribute("phoneNumber", user.getPhoneNumber());
        model.addAttribute("job", job.getJobName());
        model.addAttribute("income", income.getIncomeRange());
        model.addAttribute("myNumberCardBase64", myNumberCardBase64List);
        model.addAttribute("idCardBase64", idCardBase64List);
        
        boolean notEqualsEmail = !user.getEmail().equals(user.getEmailConfirm());
        boolean notEqualsPassword = !user.getPassword().equals(user.getPasswordConfirm());
        boolean checkEmailExists = userDetailsService.checkEmailExists(user.getEmail());
        boolean isMyNumberCardBase64 = user.getMyNumberCardBase64() == "";
        boolean isIdCardBase64 = user.getIdCardBase64() == "";
        if (notEqualsEmail || notEqualsPassword || checkEmailExists || isMyNumberCardBase64 || isIdCardBase64) {
            model.addAttribute("jobs", masterDataService.getAllJobs());
            model.addAttribute("incomes", masterDataService.getAllIncomes());
            model.addAttribute("genders", masterDataService.getAllGenders());
            model.addAttribute("emailConfirm", user.getEmailConfirm());
            model.addAttribute("password", user.getPassword());
            model.addAttribute("passwordConfirm", user.getPasswordConfirm());
            model.addAttribute("postalCode1", user.getPostalCode().split("-")[0]);
            model.addAttribute("postalCode2", user.getPostalCode().split("-")[1]);

            // selected
            model.addAttribute("genderCode", user.getGender());
            model.addAttribute("jobCode", user.getJob());
            model.addAttribute("incomeCode", user.getIncome());
            model.addAttribute("selectedYear", user.getBirthYear());
            model.addAttribute("selectedMonth", user.getBirthMonth());
            model.addAttribute("selectedDay", user.getBirthDay());

            String errMsg1 = "メールアドレスが一致しません";
            String errMsg2 = "パスワードが一致しません";
            String errMsg3 = "このメールアドレスは既に登録されています";
            String errMsg4 = "個人番号確認書類を1枚は登録してください";
            String errMsg5 = "身元確認書類を1枚は登録してください";
            String errMsg = notEqualsEmail ? errMsg1 : (notEqualsPassword ? errMsg2 : (checkEmailExists ? errMsg3 : (isMyNumberCardBase64 ? errMsg4 : errMsg5)));
            String errAtr1 = "emailError";
            String errAtr2 = "passwordError";
            String errAtr4 = "myNumberCardBase64Error";
            String errAtr5 = "idCardBase64Error";
            String errAtr = notEqualsPassword ? errAtr2 : (notEqualsEmail ? errAtr1 : (isMyNumberCardBase64 ? errAtr4 : errAtr5));
            model.addAttribute(errAtr, errMsg);
            return "register";
        }

        return "register-confirm";
    }

    @PostMapping("/update")
    public String completeUpdate(@ModelAttribute UserDto user, Model model) {

        if (checkBase64(user, false)) {
            emailService.sendErrorUserInfo(user.getLastName() + " " + user.getFirstName(), user.getEmail(), "update");
        } else {
            emailService.sendUserInfo(user.getLastName() + " " + user.getFirstName(), user.getLoginId(), user.getEmail(), "update");
            userDetailsService.updateUser(user);
            userBase64RelService.updateUserBase64Rel(user.getLoginId(), user.getMyNumberCardBase64(), user.getIdCardBase64());
        }
        return "user-complete";
    }

    @PostMapping("/complete")
    public String completeRegistration(@ModelAttribute UserDto user, Model model) {

        if (checkBase64(user, true)) {
            emailService.sendErrorUserInfo(user.getLastName() + " " + user.getFirstName(), user.getEmail(), "register");
        } else {
            emailService.sendUserInfo(user.getLastName() + " " + user.getFirstName(), user.getLoginId(), user.getEmail(), "register");
            userDetailsService.registerUser(user);
            userBase64RelService.insertUserBase64Rel(user.getLoginId(), user.getMyNumberCardBase64(), user.getIdCardBase64());
        }
        return "register-complete";
    }

    @GetMapping("/check-email")
    public ResponseEntity<Boolean> checkEmail(@RequestParam String email) {
        boolean exists = userDetailsService.checkEmailExists(email);
        return ResponseEntity.ok(exists);
    }
    
    private String generateShortUUID () {
        String loginId = UUID.randomUUID().toString().replace("-", "").substring(0, 10);
        boolean isNotExistLoginId = userDetailsService.isNotExistLoginId(loginId);
        while (!isNotExistLoginId) {
            loginId = UUID.randomUUID().toString().replace("-", "").substring(0, 10);
            isNotExistLoginId = userDetailsService.isNotExistLoginId(loginId);
        }
        return loginId;
    }

    private boolean checkBase64(UserDto user, Boolean isCreate) {

        GenderMasterEntity gender = masterDataService.findByIdentifierGender(user.getGender());
        JobMasterEntity job = masterDataService.findByIdentifierJob(user.getJob());
        IncomeMasterEntity income = masterDataService.findByIdentifierIncome(user.getIncome());

        if(isCreate) user.setLoginId(generateShortUUID());
        user.setGender(gender.getGenderCode());
        user.setJob(job.getJobCode());
        user.setIncome(income.getIncomeCode());

        boolean isMyNumberCardBase64 = true;
        boolean isIdCardBase64 = true;
        if (user.getMyNumberCardBase64() != null) {
            List<String> myNumberCardBase64List = utilService.parseBase64Array(user.getMyNumberCardBase64());
            /* TODO 画像が壊れていないか確認している。文字認識も入れたい */
            isMyNumberCardBase64 = myNumberCardBase64List.stream().noneMatch(base64 -> !utilService.isBase64(base64));
        } else {
            isMyNumberCardBase64 = false;
        }
        if (user.getIdCardBase64() != null) {
            List<String> idCardBase64List = utilService.parseBase64Array(user.getIdCardBase64());
            /* TODO 画像が壊れていないか確認している。文字認識も入れたい */
            isIdCardBase64 = idCardBase64List.stream().noneMatch(base64 -> !utilService.isBase64(base64));
        } else {
            isIdCardBase64= false;
        }
        boolean checkBase64 = !isMyNumberCardBase64 || !isIdCardBase64;

        return checkBase64;
    }
}
