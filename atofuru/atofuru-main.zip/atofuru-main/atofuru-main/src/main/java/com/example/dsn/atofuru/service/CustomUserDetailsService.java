package com.example.dsn.atofuru.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.dsn.atofuru.controller.dto.UserDto;
import com.example.dsn.atofuru.service.entity.UsersEntity;
import com.example.dsn.atofuru.service.mapper.UsersMapper;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsersMapper usersMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        UsersEntity user = usersMapper.findByEmail(userId);
        if (user == null) {
            user = usersMapper.findByLoginId(userId);
            if (user == null) {
                throw new UsernameNotFoundException("User not found with ID: " + userId);
            }
        }
        return org.springframework.security.core.userdetails.User
            .withUsername(user.getUserId())
            .password(user.getPassword())
            // .password("{noop}password") 
            .roles("USER") // 必要に応じて役割を設定
            .build();
    }

    public void registerUser(UserDto user) {
        usersMapper.insert(dtoToEntity(user, true));
    }
    
    public void updateUser(UserDto user) {
        UsersEntity userEntity = dtoToEntity(user, false);
        usersMapper.update(userEntity);
    }    
    
    private UsersEntity dtoToEntity(UserDto user, Boolean isCreate) {
        UsersEntity entity = new UsersEntity(isCreate);
        entity.setLoginId(user.getLoginId());
        entity.setLastName(user.getLastName());
        entity.setFirstName(user.getFirstName());
        entity.setLastNameKana(user.getLastNameKana());
        entity.setFirstNameKana(user.getFirstNameKana());
        entity.setEmail(user.getEmail());
        if (isCreate) {
            entity.setPassword(user.getPassword());
        } else {
            entity.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        entity.setBirthDate(
            LocalDate.parse(
                user.getBirthYear() + "-"
                + String.format("%02d", Integer.parseInt(user.getBirthMonth())) + "-" 
                + String.format("%02d", Integer.parseInt(user.getBirthDay())), 
                DateTimeFormatter.ISO_LOCAL_DATE
            )
        );
        entity.setPostalCode(user.getPostalCode());
        entity.setAddress(user.getAddress());
        entity.setPhoneNumber(user.getPhoneNumber());
        entity.setJobCode(user.getJob());
        entity.setIncomeCode(user.getIncome());
        entity.setGenderCode(user.getGender());

        return entity;
    }
    public boolean isNotExistLoginId(String loginId) {
        return usersMapper.findByLoginId(loginId) == null ? true : false;
    }
    
    public boolean checkEmailExists(String email){
        return usersMapper.checkEmailExists(email);
    }

    public UsersEntity findByLoginIdOrEmail(String identifier) {
        return usersMapper.findByIdentifier(identifier);
    }

    public UsersEntity findByUserId(Integer userId) {
        return usersMapper.findByUserId(userId);
    }
    
}
