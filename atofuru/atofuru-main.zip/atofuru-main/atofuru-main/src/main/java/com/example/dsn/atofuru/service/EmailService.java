package com.example.dsn.atofuru.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    @Autowired
    private UtilService utilService;
    
    private final JavaMailSender javaMailSender;
    
    public EmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public void sendUserInfo(String userName, String loginId, String email, String type) {
        Map<String, String> map = new HashMap<>();
        map.put(type, "利用者登録");
        map.put(type, "利用者情報変更");

        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setTo(email);
            helper.setSubject("【あとふる】" + map.get(type) + "完了のご案内");
            String htmlContent = "<!DOCTYPE html>" +
                "<html lang=\"ja\">" +
                "<head>" +
                "    <meta charset=\"UTF-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "    <title>Confirmation Email</title>" +
                "</head>" +
                "<body>" +
                "<div>" + userName + "　様</div>" +
                "<br/>" + 
                "<div>後からふるさと納税【あとふる】の" + map.get(type) + "いただきありがとうございます。</div>" +
                "<br/>" + 
                "<div>" + map.get(type) + "を完了致しましたのでご案内申し上げます。</div>" +
                "<div>▼利用者情報-----------------------</div>" +
                "<div>・受付日時：" + utilService.getStringDate() + "</div>" + 
                "<div>・会員ⅠD：" + loginId + "</div>" +
                "<div>・利用者名：" + userName + "　様</div>" +
                "<br/>" + 
                "<div>※発行された会員ⅠDまたはご登録のメールアドレスにてログインしてください</div>" +
                "<div>※パスワードはセキュリティ上表示しておりません。</div>" +
                "<div>※パスワードやメールアドレス等の利用者情報の変更はログイン後に「利用者情報」から返信できます。</div>" +
                "<br/>" + 
                "<div>このメールは送信専用のため返信いただけません。ご了承ください。</div>" +
                "<br/>" + 
                "<div>ログインはこちらから。" +
                "<br/>" + 
                "<div>" + utilService.getProjectUrl() + "</div>" +
                "</body>" +
                "</html>";
            helper.setText(htmlContent, true);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        javaMailSender.send(mimeMessage);
    }

    public void sendErrorUserInfo(String userName, String email, String type) {
        
        Map<String, String> map = new HashMap<>();
        map.put(type, "利用者登録");
        map.put(type, "利用者情報変更");

        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setTo(email);
            helper.setSubject("【あとふる】" + map.get(type) + "失敗のご案内");
            String htmlContent = "<!DOCTYPE html>" +
                "<html lang=\"ja\">" +
                "<head>" +
                "    <meta charset=\"UTF-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "    <title>Confirmation Email</title>" +
                "</head>" +
                "<body>" +
                "<div>" + userName + " 様</div>" +
                "<br/>" + 
                "<div>後からふるさと納税【あとふる】に" + map.get(type) + "いただきありがとうございます。</div>" +
                "<br/>" + 
                "<div>アップロードされた画像や入力内容にお間違いないか、ご確認の上もう一度利用者登録をお願いいたします。</div>" +
                "<br/>" + 
                "<div>以下の画像はカメラの枠に収まるように撮影してください。</div>" +
                "<div>・申告特例申請書</div>" +
                "<div>・個人番号確認書類</div>" +
                "<div>・身元確認書類</div>" +
                "<br/>" + 
                "<div>詳細はこちらから。</div>" +
                "<div>" + utilService.getProjectUrl() + "</div>" +
                "<br/>" + 
                "<br/>" + 
                "<div>※本メールにお心当たりのない方は、お手数ですが本メールを破棄してください。</div>" + 
                "</body>" +
                "</html>";            
            helper.setText(htmlContent, true);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        javaMailSender.send(mimeMessage);
    }
}
