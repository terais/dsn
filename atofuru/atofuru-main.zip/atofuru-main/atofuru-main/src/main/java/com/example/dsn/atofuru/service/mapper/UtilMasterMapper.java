package com.example.dsn.atofuru.service.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.dsn.atofuru.service.entity.UtilMasterEntity;

@Mapper
public interface UtilMasterMapper {

    UtilMasterEntity selectByKey(String systemKey1, String systemKey2);
}
